<?php 
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include 'php/conn.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$userId = $_SESSION['user_id'];


$stmt = $conn->prepare("
    SELECT o.id, o.size, o.status,o.address, o.orderNumber, p.name, o.price
    FROM orders o
    JOIN products p ON o.productId = p.id
    WHERE o.userId = ?
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$cartItems = [];
while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
}


$myData = $conn->prepare("SELECT * FROM users WHERE id = ?");
$myData->bind_param("i", $userId);
$myData->execute();
$myData_result = $myData->get_result();
$myData_fetched = $myData_result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | Profile</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/profile.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<style>

</style>
<body>
    <?php include_once "components/header.php" ?>
    <main>
        <div class="profile-container">
            <div class="profile-container-header">
                <div class="profile-container-header-banner"></div>
                <div class="profile-container-header-content">
                    <img src="img/profile.jpg" alt="">
                    <span></span>
                    <span style="font-size:1rem; font-weight: 700;">Orders</span>
                </div>
            </div>
            <div class="profile-container-info">
                <h3><?php echo $myData_fetched['username']; ?></h3>
                <span><?php echo $myData_fetched['email']; ?></span>
            </div>
            <div class="profile-container-splitter"></div>
            <div class="profile-container-orders">


                <!-- <div class="profile-container-order">
                    <div style="display: flex; align-items: center; gap: 5px;">
                        <span style="font-size: 1.125rem; font-weight:700;">Dress</span>
                        <span style="height: 15px; width: 1px; background: hsl(0, 0%, 35%);"></span>
                        <span style="font-size: 0.875rem; color: hsl(0, 0%, 45%);">$59.00</span>
                    </div>
                    <div class="profile-container-order-sit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48"><path fill="currentColor" stroke="currentColor" stroke-width="4" d="M24 33a9 9 0 1 0 0-18a9 9 0 0 0 0 18Z"/></svg>
                        <span>Sent</span>
                    </div>
                </div>  -->


                <?php if (empty($cartItems)): ?>
                    <p>Your cart is empty</p>
                <?php else: ?>
                    <?php foreach ($cartItems as $item): ?>
                        <div class="profile-container-order">
                            <div style="display: flex; flex-direction: column; gap: 10px;">
                                <div style="display: flex; align-items: center; gap: 5px;">
                                    <span style="font-size: 1.125rem; font-weight:700;">
                                        <?= htmlspecialchars($item['name']) ?>
                                    </span>
                                    <span style="height: 15px; width: 1px; background: hsl(0, 0%, 35%);"></span>
                                    <span style="font-size: 0.875rem; color: hsl(0, 0%, 45%);">
                                        $<?= number_format($item['price'], 2) ?>
                                    </span>
                                </div>
                                <span style="color: grey; display: flex; align-items: center; gap: 5px; font-size: 0.875rem">Order Number: <?= number_format($item['orderNumber']) ?></span>
                                <span style="color: grey; display: flex; align-items: center; gap: 5px; font-size: 0.875rem">Size: <?= htmlspecialchars($item['size']) ?></span>
                                <span style="color: grey; display: flex; align-items: center; gap: 5px; font-size: 0.875rem">Address: <?= htmlspecialchars($item['address']) ?></span>
                            </div>
                            <?php
                                $status = strtolower($item['status']);
                                switch ($status) {
                                    case 'pending':
                                        $color = '#facc15';
                                        break;
                                    case 'sent':
                                        $color = '#22c55e';
                                        break;
                                    case 'cancelled':
                                        $color = '#ef4444';
                                        break;
                                    case 'kargo':
                                        $color = '#f97316';
                                        break;
                                    default:
                                        $color = '#9ca3af';
                                }
                                ?>
                            <div class="profile-container-order-sit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48">
                                    <path fill="<?= $color ?>" stroke="<?= $color ?>" stroke-width="4" d="M24 33a9 9 0 1 0 0-18a9 9 0 0 0 0 18Z"/>
                                </svg>
                                <span><?= htmlspecialchars($item['status']) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

            </div>
        </div>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>