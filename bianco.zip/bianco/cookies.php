<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | privacy</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<style> 
h4{
    margin : 0 auto;
    width : 100%;
    display: flex;
    justify-content: center;
    margin:50px 0;
}
p{
    display: flex;
    justify-content: center;
    
}
main{
    padding: 0 200px 200px 200px;
    min-height: 100vh;
}
@media only screen and (max-width: 600px) {
    h4{
        margin: 20px 0;
    }
    main{
        padding: 0 20px 20px 20px;
    }
}

</style>
<body>
    <?php include_once "components/header.php" ?>
    <main> 
        <h4> COOKİES SETTİNGS </h4> 
        <p>Cookies and similar technologies are an integral part of the operation of our Platform. The main purpose of cookies is to make your browsing experience more comfortable and efficient and to improve our services and the Platform itself. Cookies are also used to show you advertisements that interest you when you visit third-party websites and applications. Here you can find information about all the cookies we use and enable and/or disable cookies according to your preferences, except for those strictly necessary for the operation of the Platform. Please note that blocking certain cookies may affect your experience on the Platform and the operation of the Platform. For more information, see our Cookie Policy.
        </p>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>