<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
include_once "php/conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ? or username = ?");
        $stmt->bind_param("ss", $email, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: index.php");
                exit;
            } else {
                echo "Incorrect password.";
            }
        } else {
            echo "User not found.";
        }

        $stmt->close();
    } else {
        echo "Please enter both email and password.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | login</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <?php include_once "components/header.php" ?>
    <main>
        <div class="left">
            <div class="form-container">
            <div class="logo-container">LOGIN</div>
            <form class="form" method="post">
                <div class="form-group">
                    <label for="email">Username</label>
                    <input type="text" name="email" placeholder="Enter your email/username" required="">
                </div>
                <div class="form-group">
                    <label for="email">Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required="">
                </div>
                <button class="form-submit-btn" type="submit">Login</button>
            </form>
            <p class="signup-link">
                Don't have an account?
                <a href="register.php" class="signup-link link"> Sign up now</a>
            </p>
            </div>
        </div>

        <section class="right" id="map">
            <div class="right-container">
            <div style="display: flex; align-items: center; gap: 5px; color: white;">
                <span class="bianco" style="font-size: 4rem;">BIANCO</span>
                <span class="essentia" style="font-size: 2rem;">Essentia</span>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit...</p>
            </div>
        </section>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>