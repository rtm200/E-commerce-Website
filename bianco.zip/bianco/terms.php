<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | privacy</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<style> 
h4{
    margin : 0 auto;
    width : 100%;
    display: flex;
    justify-content: center;
    margin:50px 0;
}
p{
    display: flex;
    justify-content: center;
    
}
main{
    padding: 0 200px 200px 200px;
}
@media only screen and (max-width: 600px) {
    h4{
        margin: 20px 0;
    }
    main{
        padding: 0 20px 20px 20px;
    }
}

</style>
<body>
    <?php include_once "components/header.php" ?>
    <main> 
        <h4> TERMS AND CONDITIONS OF PURCHASE AND USE </h4> 
        <p> 
        1. INTRODUCTION
        This document (together with the documents mentioned herein) establishes the general terms and
        conditions that govern the use of this website (www.bianco.com/ww) and the purchase of products on
        it (hereinafter referred to as the "Conditions"), irrespective of whatever application, digital medium,
        support or device is used to access said website.
        WE URGE YOU TO READ THE CONDITIONS AND OUR PRIVACY AND COOKIES POLICY (HEREINAFTER, THE
        “PRIVACY AND COOKIES POLICY”) CAREFULLY BEFORE USING AND/OR PLACING AN ORDER FROM THIS
        WEBSITE. THEY MAY SEEM TECHNICAL AND LEGALISTIC, BUT THEY ARE IMPORTANT. BY USING THIS
        WEBSITE AND /OR PLACING AN ORDER FROM THIS WEBSITE, YOU ACCEPT THESE CONDITIONS AND OUR
        PRIVACY AND COOKIES POLICY WITHOUT ANY RESERVATIONS OR QUALIFICATIONS, AND YOU AGREE TO
        BE BOUND BY THESE CONDITIONS AND OUR PRIVACY AND COOKIES POLICY. THIS INCLUDES, WITHOUT
        LIMITATION AND WHERE APPLICABLE, ACCEPTING THE TERMS RELATING TO BINDING ARBITRATION,
        WAIVER OF THE RIGHT TO CLASS ACTION, DISPUTE RESOLUTION, DISCLAIMER OF WARRANTIES, DAMAGE
        AND REMEDY EXCLUSIONS AND LIMITATIONS, AND CHOICE OF LAW AS SET FORTH HEREIN. IF YOU DON’T
        AGREE WITH THE CONDITIONS AND WITH THE PRIVACY AND COOKIES POLICY, WHETHER IN WHOLE OR
        IN PART, PLEASE DO NOT USE THE WEBSITE, OR ANY OF THE SERVICES PROVIDED ON THE WEBSITE OR
        PLACE AN ORDER FROM WEBSITE.<br>
        These Conditions may be modified. It is your responsibility to read them periodically, as the Conditions at
        the time of using the website or concluding of the relevant Contract (as defined further on) shall be those
        that apply.
        If you have any query regarding the Conditions or the Privacy and Cookies Policy, you may contact us by
        sending an email to contact_ww@bianco.com.
        The Contract (as defined below) may be executed, at your choice, in any of the languages (English, French,
        Spanish or Portuguese) in which the Conditions are available on this website.
        This Contract is available at all times on the website. Likewise, at any time throughout the purchase
        process you can store and reproduce these Conditions through the "Download" and "Print" options which
        are in the header of the document.<br>
        2. OUR DETAILS
        Sale of goods through this website is carried out under the name BİANCO by FASHION RETAIL, S.A., a
        Spanish company with registered address at Avda. de la Diputación, Edificio Inditex, 15143 Arteixo, A
        Coruña (Spain), with e-mail address contact_ww@BİANCO.com, registered with the Companies Register
        of A Coruña, on Volume 3.425, General Section, Sheet 49, Page C-47.731, 1st entry, with tax identification
        number No. A-70301981.<br>
        3. YOUR DETAILS AND YOUR VISITS TO THIS WEBSITE
        The information or personal details that you provide us shall be processed in accordance with the Privacy
        and Cookies Policy. When you use this website, you agree to the processing of the information and details
        and you state that all information and details provided are true and correspond to reality.<br>

        4. USE OF OUR WEBSITE
        When you use this website and place orders through it, you agree to:
        <br>i. Use this website to make enquiries and legally valid orders only.
        <br>ii. Use the website in a diligent manner appropriate to current legislation, morality, decent conduct and
        public order, and in all cases, in accordance with the purpose for which the website exist.
        <br>iii. Not to make any false or fraudulent orders. If an order of this type may reasonably be considered to
        have been placed, we shall be authorised to cancel it and inform the competent authorities.
        <br>iv. Not use the website for illegal purposes or effects, or in a manner in breach of these Conditions, that
        may damage third-party interests or rights, or in any way damage, impair, disable or make the website
        inaccessible, or impede its normal use for other users.
        <br>v. Not destroy, alter, render useless or in any other way damage the data, programs or electronic
        documents found in the website.
        <br>vi. Not hinder other users accessing the service by the mass consumption of computer resources used by
        BİANCO to provide the website, and also to not take any actions that damage, interrupt or generate
        errors in said systems.
        <br>vii. Not introduce programs, viruses, macros, applets, drawings, audio and/or image files, photographs,
        recordings, software and, in general, any type of material accessible via the website.
        <br>viii. Provide us with your email address, postal address and/or other contact details truthfully and exactly.
        You also agree that we may use this information to contact you in the context of your order if necessary
        (see our Privacy and Cookies Policy). If you do not provide us with all the information we need, you cannot
        place your order.
        When you place an order on this website, you state that you are over the age of 18 and are legally eligible
        to enter into binding contracts.
        Additionally, by placing the corresponding order and where applicable, you undertake to comply with the
        applicable laws of your jurisdiction as importer of record as well as to perform any other procedures that
        must be carried out for the dispatch of the merchandise from your place of residence.<br>
        5. FORMALISING THE CONTRACT
        To place an order, you must follow the online purchasing procedure and click on “Authorise payment".
        After doing so, you will receive an email confirming receipt of your order (the "Order Confirmation"). You
        will be informed via email that the order is being sent (the “Shipping Confirmation").
        These Conditions and the Contract constitute a written agreement between us, and a link to the
        agreement will be sent to you together with each of the abovementioned transactional emails.
        If you are a registered user, a record of each transaction placed by you is available in the "My Account"
        section for a 2-year period.
        By accepting these Conditions, you confirm that you have had the opportunity to either accept or reject
        them, and to correct any errors in the Contract prior to entering into it, as provided in clause 6 below.
        The Parties herein have agreed that the warranties implied by the applicable regulations (and as may be
        amended or replaced thereafter) are excluded, whenever possible and in accordance with the terms and
        conditions prescribed by law, and do not apply to this contract unless specifically stated otherwise.<br>
        6. TECHNICAL MEANS TO CORRECT ERRORS
        In case you detect that an error occurred when entering your personal data during your registration as a
        user of this website, you can modify them in the section "My Account".
        In any case, you will be able to correct errors related to the personal data provided during the purchase
        process by contacting the customer service via the email address contact_ww@BİANCO.com, as well as
        exercising the right of rectification contemplated in our Privacy and Cookies Policy. This website displays
        confirmation boxes in various sections of the purchase process that do not allow the order to continue if
        the information in these sections has not been correctly provided. Also, this website offers details of all
        the items you have added to your shopping cart during the purchase process, so that before making the
        payment, you can modify the details of your order.
        If you detect an error in your order after the completion of the payment process, you should immediately
        contact our customer service through email address above to correct the error.<br>
        7. AVAILABILITY OF PRODUCTS
        All product orders are subject to availability. Along this line, if there are difficulties regarding the supply
        of products or there are no more items left in stock, we will reimburse any amount that you may have
        paid.<br>
        8. REFUSAL TO PROCESS AN ORDER
        We reserve the right to remove any product from this website at any time and to remove or modify any
        material or content from the same. Although we will always do everything possible to process all orders,
        there may be exceptional circumstances that force us to refuse to process an order after having sent the
        Order Confirmation. We reserve the right to do so at any time.
        We shall not be liable to you or to any third party for removing any product from this website, or for
        removing or modifying any material or content from the website or not processing an order once we have
        sent the Order Confirmation.<br>
        9. DELIVERY
        Notwithstanding Clause 7 above regarding product availability and except for extraordinary
        circumstances, we will endeavor to send the order consisting of the product(s) listed in each Shipping
        Confirmation prior to the date indicated in the Shipping Confirmation in question or, if no delivery date is
        specified, in the estimated timeframe indicated when selecting the delivery method and, in any case
        within a maximum period of 30 days from the date of the Order Confirmation.
        Nonetheless, there may be delays for reasons such as the occurrence of unforeseen circumstances or the
        delivery zone.
        If for any reason we are unable to comply with the delivery date, we will inform you of that situation and
        we will give you the option to continue with the purchase, establishing a new delivery date, or cancel the
        order with full reimbursement of the amount paid. Keep in mind in any case that we do not make home
        deliveries on Saturdays, Sundays or bank holidays.
        For the purpose of these Conditions, the "delivery" shall be understood to have taken place or the order
        "delivered" as soon as you or a third party indicated by you acquires physical possession of the goods,
        which will be evidenced by the signing of the receipt of the order at the delivery address indicated by you.<br>
        10. INABILITY TO DELIVER
        If it is impossible for us to deliver your order, we will attempt to find a safe place to leave it. If we cannot
        find a safe place, your order will be returned to our warehouse.
        We will also leave a note explaining where your order is located and what to do to have it delivered again.
        If you will not be at the place of delivery at the agreed time, we ask you to contact us to organize delivery
        on another day.
        If after 30 days from the date your order is available for delivery, the order could not be delivered for
        reasons not attributable to us, we shall assume that you wish to cancel the Contract and it will be
        terminated. As a result of the termination of the Contract, we will return to you all payments received
        from you, including delivery charges (except for any additional charges resulting from your choice of any
        delivery method other than the ordinary delivery method that we offer) without any undue delay, and at
        any rate, within 14 days of the date on which this Contract has been terminated.
        Please keep in mind that transport derived from the termination of the Contract may have an additional
        cost which we will be entitled to pass on to you. 
        </p>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>