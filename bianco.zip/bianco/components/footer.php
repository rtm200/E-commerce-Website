<style>
footer{
    background-color:rgb(39, 39, 39);
    padding: 20px 0;
    
}
.footer_container{
    display: flex;
   justify-content:center;
  
    gap: 3rem ;

}
.footer_container ul{
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 13px;
    color: white;
    text-align: left;
    justify-content:start;
    align-items: center;
   

}

.footer_container a{
    color: white;
    text-decoration: none;
    font-size: 13px;
}
.footer_container a:hover{
    text-decoration: underline;
}
@media only screen and (max-width: 1000px) {
    
  }
</style>

<footer>
    <div style="width: 80%; margin: 0 auto;">
        <div class="footer_container">
            <ul>    
                <div style="display: flex; justify-content: center; align-items: center; margin-bottom:10px; gap: 2rem; ">
                    <li><a href="https://web.whatsapp.com/" target="_blank" style="font-size:15px;"><i class='bx bx-phone-call' ></i>Call us 808080 </a></li>
                    <li><a href="https://web.whatsapp.com/" target="_blank" style="font-size:15px;"><i class='bx bxl-whatsapp' ></i>Whatsapp</a></li>
                </div>
                <li><a href="privacy.php">PRIVACY AND COOKIES POLICY</a></li>
                <li><a href="cookies.php">COOKIES SETTINGS</a></li>
                <li><a href="terms.php">TERMS OF USE</a></li>
            </ul>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 10px;">
            <span style="font-size: 0.875rem; color: rgb(149, 149, 149) ;">© 2025 BIANCO</span>
        </div>
    </div>
</footer>