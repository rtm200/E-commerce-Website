<?php 
    session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | Shop</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<style>
    body{
        min-width: 700px;
    }
    main {
        display: flex;
        padding: 2rem;
        gap: 2rem;
        align-items: flex-start;
    }

    .filter-sidebar {
        width: 250px;
        background: #fff;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        position: sticky;
        top: 0px;
    }

    .filter-sidebar h3 {
        font-size: 1.2rem;
        margin-bottom: 1.2rem;
        border-bottom: 1px solid #ddd;
        padding-bottom: 0.5rem;
    }

    .filter-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
        width: 100%;
    }

    .filter-group h4 {
        font-size: 1rem;
        margin-bottom: 0.5rem;
        color: hsl(0, 0%, 45%);
    }

    .filter-group .filter-group-holder {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 0.9rem;
        margin: 6px 0;
        cursor: pointer;
    }
    .filter-group .filter-group-holder input{
       width: auto;
       cursor: pointer;
    }
    

    .product-grid {
        flex: 1;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 24px;
        margin:0;
    }

    .product-card {
        background-color: #fff;
        cursor: pointer;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border: 5px solid hsl(0, 0%, 100%);
    }

    .product-card:hover {
        box-shadow: 0 0px 20px hsl(0, 0%, 80%);
        border: 5px solid white;
    }

    .product-card img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        transition: 0.3s ease;
    }

    .product-card h3 {
        font-size: 1rem;
        padding: 12px 16px 8px;
        color: #333;
    }

    .product-card p {
        padding: 4px 16px;
        font-size: 0.95rem;
        color: #333;
    }

    .product-card span {
        display: inline-block;
        margin-right: 8px;
    }

    .product-card span:first-child {
        text-decoration: line-through;
        color: #999;
    }

    .product-card span:last-child {
        color: #e63946;
        font-weight: 600;
    }
    .image-container {
        position: relative;
        width: 100%;
        height: auto;
    }

    .main-image,
    .hover-image {
        width: 100%;
        height: auto;
        display: block;
    }

    .hover-image {
        display: none;
        z-index: 2;
    }
</style>
<body>
    <?php include_once "components/header.php" ?>
    <main>
        <aside class="filter-sidebar">
            <h3>Filters</h3>
            <div class="filter-group">
                <h4>Favorite</h4>
                <div class="filter-group-holder">
                    <span>My Favorites</span>
                    <input type="checkbox" class="filter" name="favorite"> 
                </div>
            </div>
            <div class="filter-group">
                <h4>Category</h4>
                <div class="filter-group-holder">
                    <span>Ayakkabı</span>
                    <input type="checkbox" class="filter" name="category" value="1"> 
                </div>
                <div class="filter-group-holder">
                    <span>Üst Giyim</span>
                    <input type="checkbox" class="filter" name="category" value="3">
                </div>
                <div class="filter-group-holder">
                    <span>Elbise</span>
                    <input type="checkbox" class="filter" name="category" value="2">
                </div>
                <div class="filter-group-holder">
                    <span>Alt Giyim</span>
                    <input type="checkbox" class="filter" name="category" value="4">
                </div>
            </div>

            <div class="filter-group">
                <h4>Price</h4>
                <div class="filter-group-holder">
                    <span>Min:</span>
                    <input type="number" class="filter" name="min_price" min="0" placeholder="Min Price">
                </div>

                <div class="filter-group-holder">
                    <span>Max:</span>
                    <input type="number" class="filter" name="max_price" min="0" placeholder="Max Price">
                </div>
            </div>

            <div class="filter-group">
                <h4>Price</h4>
                <div class="filter-group-holder">
                    <span>Lowest Price</span>
                    <input type="radio" class="filter" name="price_order" value="asc">
                </div>
                <div class="filter-group-holder">
                    <span>Highest Price</span>
                    <input type="radio" class="filter" name="price_order" value="desc">
                </div>
            </div>

            <div class="filter-group">
                <h4>Popularity</h4>
                <div class="filter-group-holder">
                    <span>Popular Products</span>
                    <input type="checkbox" class="filter" name="popular" value="1">
                </div>
            </div>

            <div class="filter-group">
                <h4>Offers</h4>
                <div class="filter-group-holder">
                    <span>On Offer</span>
                    <input type="checkbox" class="filter" name="offer" value="1">
                </div>
            </div>
        </aside>

        <section id="productGrid" class="product-grid"></section>
        </main>
    <?php include_once "components/footer.php" ?>
</body>
<script>
    $(document).ready(function () {
        async function getFavoriteProductIds() {
            return $.ajax({
                url: 'php/ajax/get-favorite.php',
                method: 'GET',
                dataType: 'json'
            });
        }

        function getFilterValues() {
            const filters = {};
            const gender = getGenderFromURL();
            if (gender) filters.gender = gender;

            filters.category = $("input[name='category']:checked").map(function () {
                return $(this).val();
            }).get();

            filters.min_price = $("input[name='min_price']").val();
            filters.max_price = $("input[name='max_price']").val();

            filters.price_order = $("input[name='price_order']:checked").val();

            filters.popular = $("input[name='popular']:checked").length > 0 ? 1 : 0;
            filters.offer = $("input[name='offer']:checked").length > 0 ? 1 : 0;
            filters.favorite = $("input[name='favorite']:checked").length > 0 ? 1 : 0;

            return filters;
        }

        function getGenderFromURL() {
            const urlParams = new URLSearchParams(window.location.search);
            const genderParam = urlParams.get('gender');
            if (genderParam === 'men') return 'men';
            if (genderParam === 'women') return 'women';
            return null;
        }

        async function loadProducts() {
            const filters = getFilterValues();
            const favoriteIds = await getFavoriteProductIds();

            $.ajax({
                url: 'php/ajax/get-shop.php',
                method: 'GET',
                data: filters,
                dataType: 'json',
                success: function (data) {
                    let html = '';
                    if (data.length === 0) {
                        html = '<p>No products found.</p>';
                    } else {
                        data.forEach(product => {
                            const isFav = favoriteIds.includes(product.id.toString());

                            html += `
                                <a href="product.php?id=${product.id}" class="product-card">
                                    <div class="image-container" style="position: relative;">
                                        <img src="${product.image}" alt="${product.name}" class="main-image">
                                        <img src="${product.hover_image}" alt="${product.name}" class="hover-image">
                                    </div>
                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <div>
                                            <h3>${product.name}</h3>
                                            <p>${product.description}</p>
                                            <p style="display: flex; align-items:center;">
                                                ${product.original_price
                                                    ? `<span style="text-decoration: line-through; color: gray;">$${product.original_price}</span> 
                                                    <span style="color: black; font-weight: normal;">$${product.price}</span>`
                                                    : `$${product.price}`
                                                }
                                            </p>
                                        </div>
                                        <span class="${isFav ? 'favorited' : 'none-favorite'}" data-id="${product.id}" style="cursor:pointer;">
                                            ${isFav ? 
                                                `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.27 2 8.5 2 5.41 4.42 3 7.5 3 9.24 3 10.91 3.81 12 5.08 13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.55 11.53z"/></svg>` :
                                                `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" viewBox="0 0 24 24"><path d="M7.75 3.5C5.127 3.5 3 5.76 3 8.547C3 14.125 12 20.5 12 20.5s9-6.375 9-11.953C21 5.094 18.873 3.5 16.25 3.5c-1.86 0-3.47 1.136-4.25 2.79-.78-1.654-2.39-2.79-4.25-2.79"/></svg>`
                                            }
                                        </span>
                                    </div>
                                </a>
                            `;
                        });
                    }
                    $('#productGrid').html(html);
                }
            });
        }
        
        $('#productGrid').on('click', '.none-favorite, .favorited', function (e) {
            e.preventDefault();
            const $el = $(this);
            const productId = $el.data('id');
            const isFavorited = $el.hasClass('favorited');

            $.ajax({
                url: isFavorited ? 'php/ajax/delete-favorite.php' : 'php/ajax/post-favorite.php',
                method: 'POST',
                data: { product_id: productId },
                success: function () {
                    loadProducts();
                }
            });
        });

        loadProducts();
        $('.filter').on('change input', function () {
            loadProducts();
        });
    });
</script>
<script>
    $('#productGrid').on('mouseenter', '.product-card', function () {
        $(this).find('.main-image').css('display', "none");
        $(this).find('.hover-image').css('display', "flex");
    });

    $('#productGrid').on('mouseleave', '.product-card', function () {
        $(this).find('.hover-image').css('display', "none");
        $(this).find('.main-image').css('display', "flex");
    });
</script>
</html>