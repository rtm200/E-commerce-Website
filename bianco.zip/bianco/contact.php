<?php
    include_once "php/conn.php";
    session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | Contact</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/contact.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
</head>
<body>
    <?php include_once "components/header.php" ?>
    <main>
        <form id="contactForm" class="left">
            <div class="left-container">
                <h3>Chat to our team</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime itaque cum unde soluta debitis voluptatibus facere dignissimos. Rerum fugiat quibusdam maiores quidem! Officiis alias libero voluptates ea facere soluta vel?</p>
            </div>
            <div class="left-container">
                <h4>User Information</h4>
                <div style="width: 100%;display: flex; align-items: center; gap: 4rem;">
                <input type="text" name="first_name" placeholder="First name" required autocomplete="none">
                <input type="text" name="last_name" placeholder="Last name" required autocomplete="none">
                </div>
                <input type="email" name="email" placeholder="Email" required autocomplete="none">
                <input type="text" name="phone" placeholder="Phone number" autocomplete="none">
            </div>
            <div class="left-container">
                <h4>Request Details</h4>
                <textarea name="request" placeholder="Your message" required autocomplete="none"></textarea>
            </div>
            <button type="submit" class="buttonSecondary">Get in touch</button>
        </form>

        <section class="right" id="map">
            <div class="right-container">
                <div style="display: flex; align-items: center; gap: 5px; color: white;"><span class="bianco" style="font-size: 4rem;">BIANCO</span><span class="essentia" style="font-size: 2rem;">Essentia</span></div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo facilis, totam placeat nobis, natus tempore error quisquam ullam numquam repellat aliquam est accusantium sit aliquid perspiciatis repudiandae odit obcaecati veniam.</p>
            </div>
        </section>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
    var map = L.map('map').setView([40.94009129401022, 29.11451914046071], 10);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© BIANCO'
    }).addTo(map);

    L.marker([40.94009129401022, 29.11451914046071]).addTo(map)
        .bindPopup("<span class='bianco' style='font-size:1.25rem;'>BIANCO</span> <span class='essentia' style='font-size:1rem;'>Essentia</span>")
        .openPopup();
</script>

<script>
  $("#contactForm").on("submit", function (e) {
    e.preventDefault();

    $.ajax({
      url: "php/ajax/post-contact.php",
      type: "POST",
      data: $(this).serialize(),
      success: function (response) {
        alert("Message sent successfully!");
        $("#contactForm")[0].reset();
      },
      error: function () {
        alert("Error submitting the form.");
      }
    });
  });
</script>
</html>