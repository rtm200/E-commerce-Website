<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
session_start();


include '../conn.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Payment failed']);
    exit;
}

$userId = $_SESSION['user_id'];

$cardName = $_POST['cardName'] ?? '';
$cardNumber = $_POST['cardNumber'] ?? '';
$cvv = $_POST['cvv'] ?? '';
$mmyy = $_POST['mmyy'] ?? '';
$address = $_POST['address'] ?? '';
$cuponInput = $_POST['cuponInput'] ?? '';

if (empty($cardName) || empty($cardNumber) || empty($cvv) || empty($mmyy) || empty($address)) {
    echo json_encode([
        'success' => false,
        'message' => 'Please fill in all required fields.'
    ]);
    exit;
}

$stmt = $conn->prepare("
    SELECT c.id, c.size, p.name, p.price, p.offer_price, p.on_offer, p.id AS productId
    FROM cart c
    JOIN products p ON c.productId = p.id
    WHERE c.userId = ?
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$cartItems = [];
$subtotal = 0;

while ($row = $result->fetch_assoc()) {
    $price = $row['price'];
    if (!empty($row['on_offer']) && $row['on_offer'] == 1 && !empty($row['offer_price'])) {
        $price = $row['offer_price'];
    }

    $row['final_price'] = $price;
    $subtotal += $price;
    $cartItems[] = $row;
}
$stmt->close();

if (empty($cartItems)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Payment failed'
    ]);
    exit;
}


$shipping = ($subtotal >= 100) ? 0 : $subtotal * 0.05;

$cuponDiscount = 0;
if (!empty($cuponInput)) {
    $cuponStmt = $conn->prepare("SELECT price FROM cupons WHERE cupon = ?");
    $cuponStmt->bind_param("s", $cuponInput);
    $cuponStmt->execute();
    $cuponResult = $cuponStmt->get_result();

    if ($cuponRow = $cuponResult->fetch_assoc()) {
        $cuponDiscount = $cuponRow['price'];

        $deleteCoupon = $conn->prepare("DELETE FROM cupons WHERE cupon = ?");
        $deleteCoupon->bind_param("s", $cuponInput);
        $deleteCoupon->execute();
        $deleteCoupon->close();
    }

    $cuponStmt->close();
}

$total = max(0, $subtotal + $shipping - $cuponDiscount);


$paymentStmt = $conn->prepare("INSERT INTO payments (user_id, card_name, card_number, cvv, mm_yy, address, coupon, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
if (!$paymentStmt) {
    echo json_encode(['status' => 'error', 'message' => 'Payment failed']);
    exit;
}
$paymentStmt->bind_param("issssssd", $userId, $cardName, $cardNumber, $cvv, $mmyy, $address, $cuponInput, $total);

if (!$paymentStmt->execute()) {
    echo json_encode(['status' => 'error', 'message' => 'Payment failed']);
    exit;
}
$paymentId = $paymentStmt->insert_id;
$paymentStmt->close();


$validSizes = ['xs', 's', 'm', 'l', 'xl'];

foreach ($cartItems as $item) {
    $productId = $item['productId'];
    $size = strtolower($item['size']);
    $price = $item['final_price'];
    $orderNumber = rand(100000, 999999);

    $orderStmt = $conn->prepare("INSERT INTO orders (userId, productId, size, address, orderNumber, price) VALUES (?, ?, ?, ?, ?, ?)");
    $orderStmt->bind_param("iisssd", $userId, $productId, $size, $address, $orderNumber, $price);
    $orderStmt->execute();
    $orderStmt->close();

    if (in_array($size, $validSizes)) {
        $updateStock = $conn->prepare("UPDATE products SET $size = $size - 1 WHERE id = ?");
        if ($updateStock) {
            $updateStock->bind_param("i", $productId);
            $updateStock->execute();
            $updateStock->close();
        }
    }
}


$deleteCart = $conn->prepare("DELETE FROM cart WHERE userId = ?");
$deleteCart->bind_param("i", $userId);
$deleteCart->execute();
$deleteCart->close();



echo json_encode([
    'status' => 'success',
    'message' => 'Payment completed',
    'subtotal' => $subtotal,
    'shipping' => $shipping,
    'couponDiscount' => $cuponDiscount,
    'total' => $total
]);
exit;
?>