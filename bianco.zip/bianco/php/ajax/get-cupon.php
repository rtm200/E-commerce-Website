<?php
include_once "../conn.php";

header('Content-Type: application/json');

if (!isset($_GET['cupon'])) {
    echo json_encode(['message' => 'not a valid cupon']);
    exit;
}

$cupon = trim($_GET['cupon']);

$stmt = $conn->prepare("SELECT price FROM cupons WHERE cupon = ?");
$stmt->bind_param("s", $cupon);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'message' => "Cupon Applied! Discount: $" . $row['price'],
        'price' => $row['price']
    ]);
} else {
    echo json_encode(['message' => 'not a valid cupon']);
}


$conn->close();
?>
