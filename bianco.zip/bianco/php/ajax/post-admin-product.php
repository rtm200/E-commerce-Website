<?php
include_once "../conn.php";

function uploadFile($file, $targetDir = "../../product_images/") {
    if ($file['error'] !== 0) return '';

    $filename = basename($file['name']);
    $targetFile = $targetDir . $filename;

    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $base = pathinfo($filename, PATHINFO_FILENAME);
    $counter = 1;
    while (file_exists($targetFile)) {
        $filename = $base . '_' . $counter . '.' . $ext;
        $targetFile = $targetDir . $filename;
        $counter++;
    }

    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return "product_images/" . $filename;
    }
    return '';
}


$name = $_POST['name'];
$desc = $_POST['description'];
$price = floatval($_POST['price']);
$XS = intval($_POST['XS']);
$S = intval($_POST['S']);
$M = intval($_POST['M']);
$L = intval($_POST['L']);
$XL = intval($_POST['XL']);
$stock = $XS + $S + $M + $L + $XL;
$is_popular = 0; 
$on_offer = isset($_POST['on_offer']) ? 1 : 0;
$offer_price = $on_offer ? floatval($_POST['offer_price']) : 0;
$category_id = intval($_POST['category_id']);
$gender = $_POST['gender'];

// Upload main image
$mainImageName = '';
if (isset($_FILES['image'])) {
    $mainImageName = uploadFile($_FILES['image']);
}

// Insert product
$stmt = $conn->prepare("INSERT INTO products 
    (name, description, price, XS, S, M, L, XL, stock, is_popular, on_offer, offer_price, category_id, gender, image)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssdddddddiiidss", 
    $name, $desc, $price, $XS, $S, $M, $L, $XL, $stock, $is_popular, $on_offer, $offer_price, $category_id, $gender, $mainImageName);

if(!$stmt->execute()) {
    echo "Error inserting product: " . $stmt->error;
    exit;
}

$product_id = $stmt->insert_id;
$stmt->close();

// Upload gallery images
if (isset($_FILES['gallery'])) {
  
    foreach ($_FILES['gallery']['tmp_name'] as $index => $tmpName) {
        if ($_FILES['gallery']['error'][$index] === 0) {
            $fileArray = [
                'name' => $_FILES['gallery']['name'][$index],
                'type' => $_FILES['gallery']['type'][$index],
                'tmp_name' => $tmpName,
                'error' => $_FILES['gallery']['error'][$index],
                'size' => $_FILES['gallery']['size'][$index],
            ];
            $fileName = uploadFile($fileArray);
            if ($fileName) {
                $stmt = $conn->prepare("INSERT INTO product_gallery (product_id, image) VALUES (?, ?)");
                $stmt->bind_param("is", $product_id, $fileName);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
}

echo "success";
?>
