<?php
session_start();
include_once "../conn.php";

header('Content-Type: application/json');

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$productId = $_POST['product_id'] ?? null;
if (!$productId) {
    echo json_encode(['error' => 'No product specified']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM favorite_products WHERE user_id = ? AND product_id = ?");
$stmt->bind_param("ii", $userId, $productId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to remove favorite']);
}