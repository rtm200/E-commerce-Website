<?php
session_start();
include_once "../conn.php";

header('Content-Type: application/json');

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$productId = $_POST['product_id'] ?? null;
if (!$productId) {
    echo json_encode(['error' => 'No product specified']);
    exit;
}


$stmtCheck = $conn->prepare("SELECT 1 FROM favorite_products WHERE user_id = ? AND product_id = ?");
$stmtCheck->bind_param("ii", $userId, $productId);
$stmtCheck->execute();
$stmtCheck->store_result();

if ($stmtCheck->num_rows > 0) {
    echo json_encode(['message' => 'Already favorited']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO favorite_products (user_id, product_id) VALUES (?, ?)");
$stmt->bind_param("ii", $userId, $productId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to add favorite']);
}