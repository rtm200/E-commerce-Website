<?php

require '../conn.php';

$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$stock = $_POST['stock'];
$gender = $_POST['gender'];
$on_offer = $_POST['on_offer'];
$offer_price = $_POST['offer_price'];
$category_id = $_POST['category_id'];

$stmt = $conn->prepare("UPDATE products SET name=?, price=?, description=?, stock=?, gender=?, on_offer=?, offer_price=?, category_id=? WHERE id=?");
$stmt->bind_param("sdsissdii", $name, $price, $description, $stock, $gender, $on_offer, $offer_price, $category_id, $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to update"]);
}

?>
