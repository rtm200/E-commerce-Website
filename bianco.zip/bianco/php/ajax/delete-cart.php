<?php
session_start();
require '../conn.php';

$user_id = $_SESSION['user_id'];
$cart_id = $_POST['cart_id'];

$stmt = $conn->prepare("DELETE FROM cart WHERE userId = ? AND id = ?");
$stmt->bind_param("ii", $user_id, $cart_id);
$stmt->execute();

echo "success";
