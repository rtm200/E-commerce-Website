<?php
include_once "../conn.php";
session_start();


$userId = $_SESSION['user_id'] ?? null;


$query = "SELECT * FROM products";
$where = [];
$params = [];
$types = "";
$orderBy = "";

// Gender
if (!empty($_GET['gender'])) {
    if ($_GET['gender'] == 'men' || $_GET['gender'] == 'women'){
        $where[] = "gender = ?";
        $params[] = $_GET['gender'];
        $types .= "s";
    } else {
        die();
    }
}

// Favorite filter
if (isset($_GET['favorite']) && $_GET['favorite'] == 1) {
    if (!$userId) {
        die(json_encode(['error' => 'Not logged in']));
    }

    $where[] = "id IN (SELECT product_id FROM favorite_products WHERE user_id = ?)";
    $params[] = $userId;
    $types .= "i";
}


// Category
if (!empty($_GET['category']) && is_array($_GET['category'])) {
    $placeholders = implode(',', array_fill(0, count($_GET['category']), '?'));
    $where[] = "category_id IN ($placeholders)";
    foreach ($_GET['category'] as $cat) {
        $params[] = $cat;
        $types .= "s";
    }
}

// Min price
if (!empty($_GET['min_price'])) {
    $where[] = "(CASE 
                    WHEN on_offer = 1 THEN offer_price 
                    ELSE price 
                END) >= ?";
    $params[] = (float)$_GET['min_price'];
    $types .= "d";
}

// Max price
if (!empty($_GET['max_price'])) {
    $where[] = "(CASE 
                    WHEN on_offer = 1 THEN offer_price 
                    ELSE price 
                END) <= ?";
    $params[] = (float)$_GET['max_price'];
    $types .= "d";
}

// Price
if (!empty($_GET['price_order'])) {
    $order = $_GET['price_order'];
    if ($order === 'asc') {
        $orderBy = "ORDER BY price ASC";
    } elseif ($order === 'desc') {
        $orderBy = "ORDER BY price DESC";
    }
}

// Popular
if (!empty($_GET['popular'])) {
    $where[] = "is_popular >= 1";
    $orderBy = "ORDER BY is_popular DESC";
}

// Offer
if (!empty($_GET['offer'])) {
    $where[] = "on_offer = 1";
}


if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

if (!empty($orderBy)) {
    $query .= " " . $orderBy;
}

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    
    $productId = $row['id'];
    $galleryStmt = $conn->prepare("SELECT image FROM product_gallery WHERE product_id = ? ORDER BY RAND() LIMIT 1");
    $galleryStmt->bind_param("i", $productId);
    $galleryStmt->execute();
    $galleryResult = $galleryStmt->get_result();

    if ($galleryRow = $galleryResult->fetch_assoc()) {
        $row['hover_image'] = $galleryRow['image'];
    } else {
        $row['hover_image'] = $row['image']; 
    }

    if (!empty($row['on_offer']) && $row['on_offer'] == 1 && !empty($row['offer_price'])) {
        $row['original_price'] = $row['price'];
        $row['price'] = $row['offer_price'];
    }
    $products[] = $row;
}

header('Content-Type: application/json');
echo json_encode($products);
?>
