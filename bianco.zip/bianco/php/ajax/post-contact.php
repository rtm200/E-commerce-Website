<?php
include_once "../conn.php";

$first = $_POST['first_name'] ?? '';
$last = $_POST['last_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$request = $_POST['request'] ?? '';

if ($first && $last && $email && $request) {

    $check = $conn->prepare("SELECT id, blocked FROM contact_profiles WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows === 0) {
      
        $makeChat = $conn->prepare("INSERT INTO contact_profiles (first_name, last_name, email, phone) VALUES (?, ?, ?, ?)");
        $makeChat->bind_param("ssss", $first, $last, $email, $phone);

        if (!$makeChat->execute()) {
            http_response_code(500);
            echo "Error inserting profile: " . $makeChat->error;
            $makeChat->close();
            exit();
        }

        $profileId = $conn->insert_id;
        $makeChat->close();
    } else {

        $fecthedCheck = $result->fetch_assoc();
        if ($fecthedCheck['blocked'] === 1) {
            http_response_code(500);
            echo "Profile is blocked.";
            exit();
        }

        $profileId = $fecthedCheck['id'];
    }
    $check->close();


    $sendMessage = $conn->prepare("INSERT INTO contact_messages (profileId, first_name, last_name, email, phone, `message`) VALUES (?, ?, ?, ?, ?, ?)");
    $sendMessage->bind_param("ssssss", $profileId, $first, $last, $email, $phone, $request);

    if ($sendMessage->execute()) {
        http_response_code(200);
    } else {
        http_response_code(500);
        echo "Error inserting message: " . $sendMessage->error;
    }

    $sendMessage->close();

} else {
    http_response_code(400);
    echo "Missing required fields.";
}

$conn->close();
?>
