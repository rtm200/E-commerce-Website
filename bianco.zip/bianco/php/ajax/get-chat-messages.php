<?php
include_once "../conn.php";

header('Content-Type: application/json');

$profileId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($profileId > 0) {
    $stmt = $conn->prepare("SELECT `message`, `created_at` FROM contact_messages WHERE profileId = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $profileId);
    $stmt->execute();

    $result = $stmt->get_result();
    $messages = [];

    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'message' => $row['message'],
            'created_at' => $row['created_at']
        ];
    }

    if (count($messages) > 0) {
        echo json_encode($messages);
    } else {
        echo json_encode(["message" => "No messages found for this profile."]);
    }

    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing profile ID."]);
}

$conn->close();
?>
