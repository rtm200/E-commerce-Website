<?php
session_start();
include_once "../conn.php";

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT product_id FROM favorite_products WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$favorites = [];
while ($row = $result->fetch_assoc()) {
    $favorites[] = (string)$row['product_id'];
}
echo json_encode($favorites);