<?php
include_once "../conn.php";

$sql = "SELECT id, first_name, last_name, email FROM contact_profiles ORDER BY id DESC";
$result = $conn->query($sql);

$profiles = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $profiles[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($profiles);

$conn->close();
?>