<?php
session_start();
require_once "../conn.php";

if (!isset($_SESSION['user_id'])) {
    echo "not_logged_in";
    die();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $size = isset($_POST['size']) ? $_POST['size'] : '';

    // Validate size
    $validSizes = ['XS', 'S', 'M', 'L', 'XL'];
    if (!in_array($size, $validSizes)) {
        echo "invalid_size";
        exit;
    }

    // Optional: check stock
    $stmt = $conn->prepare("SELECT `$size` FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$res || $res[$size] <= 0) {
        echo "out_of_stock";
        exit;
    }

    // Insert to cart
    $stmt = $conn->prepare("INSERT INTO cart (userId, productId, size) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $userId, $productId, $size);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "db_error";
    }
    $stmt->close();
}
?>