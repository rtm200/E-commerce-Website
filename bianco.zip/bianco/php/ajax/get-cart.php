<?php
session_start();
include '../conn.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT c.id, c.size, p.name, p.price, p.offer_price, p.on_offer, p.image, p.id AS prId
    FROM cart c
    JOIN products p ON c.productId = p.id
    WHERE c.userId = ?
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$cartItems = [];
while ($row = $result->fetch_assoc()) {
    if (!empty($row['on_offer']) && $row['on_offer'] == 1 && !empty($row['offer_price'])) {
        $row['original_price'] = $row['price'];
        $row['price'] = $row['offer_price'];
    }
    $cartItems[] = $row;
}

echo json_encode($cartItems);
?>
