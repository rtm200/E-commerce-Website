<?php
require '../conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $orderId = intval($_POST['order_id']);
    $newStatus = $_POST['status'];

    if (!in_array($newStatus, ['Sent', 'Cancelled', 'Kargo', 'Pending'])) {
        exit('Invalid status');
    }

    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $newStatus, $orderId);

    if ($stmt->execute()) {
        echo "Status updated to $newStatus";
    } else {
        echo 'Failed to update status';
    }
}
?>