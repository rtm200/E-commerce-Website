<?php 
session_start();
include_once "php/conn.php";

$result = $conn->query("SELECT * FROM products ORDER BY is_popular DESC LIMIT 8;");

$slides = "";
while ($row = $result->fetch_assoc()) {
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $desc = htmlspecialchars($row['description']);
    $price = htmlspecialchars($row['price']);
    $image = htmlspecialchars($row['image']);
    $on_offer = $row['on_offer'] ?? 0;
    $offer_price = $row['offer_price'] ?? null;

    $price_html = '';
    if ($on_offer && !empty($offer_price)) {
        $price_html = '<h4><span style="text-decoration: line-through; color: gray;">$' . $price . '</span> 
                       <span style="color: black; font-weight: bold;">$' . $offer_price . '</span></h4>';
    } else {
        $price_html = '<h4>$' . $price . '</h4>';
    }

    $slides .= '
    <swiper-slide>
        <a href="product.php?id=' . $id . '" >
            <img class="nCCimg" src="' . $image . '" alt="' . $name . '">
            <div class="nCCdesc">
                <h3>' . $name . '</h3>
                <p>' . $desc . '</p>
                ' . $price_html . '
            </div>
        </a>
    </swiper-slide>';
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | Home</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="preloader">
        <div class="preloader-hero">
            <div class="preloader-loader">
                <p>Bianco Essentia</p>
                <div class="preloader-bar"></div>
            </div>
            <div class="preloader-hero-imgs">
                <img src="img/preloader1.jpg" />
                <img src="img/preloader3.jpg" />
                <img src="img/preloader1.jpg" />
                <img src="img/preloader3.jpg"/>
            </div>
        </div>
    </div>


    <?php include_once "components/header.php" ?>
    <main style="margin-top:0; padding-top:0;">
        <section class="hero">
            <div class="heroLeft">
                <h2>Get The Look</h2>
                <p>Galerimizden ilham al ve stillerini <b>@Bianco</b> ve <b>#BiancoStyle</b> etiketleriyle sosyal medyada paylaş.</p>
            </div>
            <div class="heroRight">
                <a href="#" class="buttonPrimary">Buy Now</a>
            </div>
        </section>
        <section class="newCollection">
            <div class="newCollectionHeader">
                <h3>POPULAR ITEMS</h3>
            </div>
            <div class="newCollectionContent">
                <swiper-container class="mySwiper" pagination="true" pagination-clickable="true" breakpoints='{"0": { "slidesPerView": 1 }, "300": { "slidesPerView": 1 }, "600": { "slidesPerView": 2 }, "900": { "slidesPerView": 3 }, "1000": { "slidesPerView": 5 }}'  space-between="30" free-mode="true">
                        <?= $slides ?>
                </swiper-container>
            </div>
        </section>
        <section class="offer">
            <div class="offerImage">
                <button class="offerImageButton">
                    <p class="button__text">
                    <span style="--index: 0;">S</span>
                    <span style="--index: 1;">A</span>
                    <span style="--index: 2;">L</span>
                    <span style="--index: 3;">E</span>
                    <span style="--index: 4;"> </span>
                    <span style="--index: 5;"> </span>
                    <span style="--index: 6;">S</span>
                    <span style="--index: 7;">A</span>
                    <span style="--index: 8;">L</span>
                    <span style="--index: 9;">E</span>
                    <span style="--index: 10;"> </span>
                    <span style="--index: 11;"> </span>
                    <span style="--index: 12;">S</span>
                    <span style="--index: 13;">A</span>
                    <span style="--index: 14;">L</span>
                    <span style="--index: 15;">E</span>
                    
                    </p>
                
                    <div class="button__circle">
                    <svg
                        viewBox="0 0 14 15"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        class="button__icon"
                        width="14"
                    >
                        <path
                        d="M13.376 11.552l-.264-10.44-10.44-.24.024 2.28 6.96-.048L.2 12.56l1.488 1.488 9.432-9.432-.048 6.912 2.304.024z"
                        fill="currentColor"
                        ></path>
                    </svg>
                
                    <svg
                        viewBox="0 0 14 15"
                        fill="none"
                        width="14"
                        xmlns="http://www.w3.org/2000/svg"
                        class="button__icon button__icon--copy"
                    >
                        <path
                        d="M13.376 11.552l-.264-10.44-10.44-.24.024 2.28 6.96-.048L.2 12.56l1.488 1.488 9.432-9.432-.048 6.912 2.304.024z"
                        fill="currentColor"
                        ></path>
                    </svg>
                    </div>
                </button>
            </div>
            <div class="offerDesc">
                <h3>TRENDY</h3>
                <p>2025'in en göz alıcı parçaları</p>
                <button class="learn-more button-ct">
                    <span class="circle" aria-hidden="true">
                        <span class="icon arrow"></span>
                    </span>
                    <a href="#" class="button-text">See Details</a>
                </button>
            </div>
        </section>
        <section class="cat">
            <div class="catCard erkekBg">
                <div class="catCardDesc">
                    <h3>MAN</h3>
                    <a href="shop.php?gender=men" class="buttonPrimary">See Details</a>
                </div>
            </div>
            <div class="catCard kadinBg">
                <div class="catCardDesc">
                    <h3>WOMAN</h3>
                    <a href="shop.php?gender=women" class="buttonPrimary">See Details</a>
                </div>
            </div>
            <div class="catCard shopBg">
                <div class="catCardDesc">
                    <h3>SHOP</h3>
                    <a href="shop.php" class="buttonPrimary">Visit Shop</a>
                </div>
            </div>
        </section>
    </main>
    <?php include_once "components/footer.php" ?>
</body>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js"></script>

<script src="https://unpkg.com/scrollreveal"></script>

<script>
    ScrollReveal({ 
        reset: false, 
        distance: '60px', 
        duration: 1500, 
        delay: 200 
    });

    ScrollReveal().reveal('.heroLeft', { origin: 'left' });
    ScrollReveal().reveal('.heroRight', { origin: 'right' });

    ScrollReveal().reveal('.newCollectionHeader', { origin: 'top' });
    ScrollReveal().reveal('.newCollectionContent', { origin: 'bottom', interval: 200 });

    ScrollReveal().reveal('.offerImageButton', { origin: 'left' });
    ScrollReveal().reveal('.offerDesc', { origin: 'right' });

    ScrollReveal().reveal('.catCard', { origin: 'bottom', interval: 200 });
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("biancoPreloaderShown")) {
      document.querySelector(".preloader").style.display = "none";
      return;
    }
    else{
        document.querySelector(".preloader").style.display = "flex";
    }
    localStorage.setItem("biancoPreloaderShown", "true");

    gsap.to(".preloader-bar", {
      width: "30%",
      duration: 2,
      ease: "power4.inOut",
      delay: 0,
    });

    gsap.to(".preloader-bar", {
      width: "100%",
      opacity: 0,
      duration: 2,
      ease: "power3.out",
      delay: 3,
      onComplete: () => {
        gsap.set(".preloader-loader", {
          display: "none",
        });
      },
    });

    gsap.to(".preloader-bar", {
      x: "-100%",
      duration: 2,
      ease: "power4.inOut",
      delay: 3,
    });

    gsap.to(".preloader-hero-imgs > img", {
      clipPath: "polygon(100% 0%, 0% 0%, 0% 100%, 100% 100%)",
      duration: 2,
      ease: "power4.inOut",
      stagger: 0.25,
      delay: 3.25,
    });

    gsap.to(".preloader-hero", {
      scale: 1.15,
      ease: "power3.inOut",
      duration: 3,
      stagger: 0.25,
      delay: 3.5,
      onComplete: () => {
        gsap.to(".preloader", {
          opacity: 0,
          duration: 1,
          ease: "power3.inOut",
          onComplete: () => {
            gsap.set(".preloader", { display: "none" });
          }
        });
      },
    });
  });
</script>
</html>