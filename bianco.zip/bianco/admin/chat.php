
<?php

    include_once "../php/conn.php";

    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT first_name, last_name, email, phone FROM contact_profiles WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
    
     
    
        $stmt->close();
    }
    else{
        header('location: chat.php?id=1');
        exit();
    }
    
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Chat</title>
    <link rel="stylesheet" href="chat.css">
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>
    <main>
        <div class="chat-left" id="chatProfilesContainer">

        </div>
        <div class="chat-right">
            <div class="chatRight-header">
                <div class="chatRight-header-left">
                    <?php
                        
                        if($result->num_rows > 0){
                            $profile = $result->fetch_assoc();
                            if ($profile) {
                            echo'
                                <span class="header-Username">' . $profile["first_name"] . '</span>
                                <span class="header-Email">' . $profile["email"] . '</span>
                                <span class="header-phone">' . $profile["phone"] . '</span>
                            ';
                            } else {
                                die('couldnt fecth row');
                                exit();
                            }
                        }
                        else{
                            echo'
                                <span class="header-Username">Username</span>
                                <span class="header-Email">Email</span>
                                <span class="header-phone">Phone</span>
                            ';
                        }
                        
                    ?>
                </div>
                <div class="chatRight-header-right">
                    <i class='bx bx-block'></i>
                </div>
            </div>

            <div class="chatRight-MsgBox" id="messages-container">

                <!-- <div class="chatRight-MsgBox-comming">
                    <span class="chatRight-MsgBox-comming-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias eum deserunt a voluptatum fuga omnis quia, deleniti, quod doloribus beatae, mollitia officiis commodi tenetur consequuntur ducimus. Ad, reprehenderit. Saepe, natus!</span>
                    <span class="chatRight-MsgBox-comming-time">10:00</span>
                </div>
                <div class="chatRight-MsgBox-going">
                    <span class="chatRight-MsgBox-going-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias eum deserunt a voluptatum fuga omnis quia, deleniti, quod doloribus beatae, mollitia officiis commodi tenetur consequuntur ducimus. Ad, reprehenderit. Saepe, natus!</span>
                    <span class="chatRight-MsgBox-going-time">10:00</span>
                </div> -->
                

             
                 <div class="chatRight-MsgBox-blocked">
                    <div class="blocked-header">
                        <span class="blocked-left"></span>
                        <span class="blocked-center">
                            You BLOCKED this person
                        </span>
                        <span class="blocked-right"></span>
                    </div>
                    <button class="buttonPrimary" style="background-color: red; color: white;">Unblock</button>
                 </div>


            </div>
            <div class="chatRight-bottom">
                
                <div class="scroller" id="scroller"><i class='bx bx-chevron-down'></i></div>

                <input type="text" placeholder="Answer">
                <button class="buttonPrimary">Send</button>
            </div>
        </div>
    </main>
</body>
<script>
    const msgBox = document.querySelector('.chatRight-MsgBox');
    const scroller = document.getElementById('scroller');

    function scrollToBottom() {
        msgBox.scrollTop = msgBox.scrollHeight;
    }

    msgBox.addEventListener('scroll', () => {
        const atBottom = msgBox.scrollHeight - msgBox.scrollTop <= msgBox.clientHeight + 50;
        scroller.style.display = atBottom ? 'none' : 'flex';
    });

    scroller.addEventListener('click', scrollToBottom);

    scrollToBottom();


    const observer = new MutationObserver(scrollToBottom);
    observer.observe(msgBox, { childList: true });
</script>
<script>

    function loadChatProfiles() {
        $.ajax({
            url: '../php/ajax/get-chat-profiles.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                data.forEach(profile => {
                    html += `
                    <a href="chat.php?id=${profile.id}" class="chat-profile chat-profile-Active">
                        <span class="chatProfile-username">${profile.first_name} ${profile.last_name}</span>
                        <span class="chatProfile-text">${profile.email}</span>
                    </diav>`;
                });
                $('#chatProfilesContainer').html(html);
            },
            error: function(xhr) {
                console.error("Error loading profiles:", xhr.responseText);
            }
        });
    }

    loadChatProfiles();
    setInterval(loadChatProfiles, 5000);
</script>
<script>
    function fetchMessages() {
        var profileId = new URLSearchParams(window.location.search).get('id');

        if (profileId) {
            $.ajax({
                url: '../php/ajax/get-chat-messages.php',
                type: 'GET',
                data: { id: profileId },
                success: function(response) {
                    var messagesContainer = $('#messages-container');
                    messagesContainer.empty();

                    if (response.error) {
                        messagesContainer.append('<div>No messages found.</div>');
                    } else {
                        response.forEach(function(message) {
                            messagesContainer.append(
                                '<div class="chatRight-MsgBox-comming">' +
                                '<span class="chatRight-MsgBox-comming-text">' + message.message + '</span>' +
                                '<span class="chatRight-MsgBox-comming-time">' + message.created_at + '</span>' +
                                '</div>'
                            );
                        });
                    }
                },
                error: function() {
                    console.error('Error loading messages');
                }
            });
        } else {
            console.error('No profile ID found in URL');
        }
    }

    fetchMessages();
    setInterval(fetchMessages, 5000); 
</script>
</html>