<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard | Home</title>
  <link rel="stylesheet" href="../css/styles.css">
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .button-container {
      text-align: center;
    }

    .nav-button {
      padding: 1rem 2rem;
      margin: 1rem;
      font-size: 1.2rem;
      border: none;
      background-color: #333;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .nav-button:hover {
      background-color: #555;
    }

    @media (max-width: 600px) {
      .nav-button {
        width: 80%;
        font-size: 1rem;
      }
    }
  </style>
</head>
<body>
  <div class="button-container">
    <button class="nav-button" onclick="location.href='orders.php'">Orders</button>
    <button class="nav-button" onclick="location.href='products.php'">Go to Products</button>
    <button class="nav-button" onclick="location.href='chat.php'">Open Chat</button>
  </div>
</body>
</html>
