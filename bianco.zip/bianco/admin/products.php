<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Products</title>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<style>
    .container {
        display: flex;
        height: 100vh;
    }
    .left, .right {
        width: 50%;
        padding: 2rem;
        overflow-y: auto;
    }
    .left {
        background: #fff;
        border-right: 1px solid #ccc;
    }
    .right {
        background: hsl(0, 0%, 10%);
        color: white;
    }
    .product-item {
        padding: 1rem;
        margin-bottom: 0.5rem;
        cursor: pointer;
        background: hsl(0, 0%, 10%);
        color: white;
        border-radius: 6px;
        transition: 0.3s background-color;
    }
    .product-item:hover {
        background: hsl(0, 0%, 15%);
    }
    .form-group {
        margin-bottom: 1rem;
    }
    h2 {
        margin-bottom: 2rem;
    }
    label {
        display: block;
        font-weight: 500;
    }
    input, textarea {
        width: 100%;
        color: white;
        font-size: 1rem;
    }
    textarea {
        margin-top: 1rem;
        height: 100px;
    }

    .popup-overlay {
        display: none;
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.5);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }
    .popup-content {
        background: #fff;
        padding: 2rem;
        width: 400px;
        height: 100%;
        border-radius: 8px;
        position: relative;
        overflow-y: auto;
    }
    .popup-content input, .popup-content textarea {
        color: black;
    }
    .popup-close {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 20px;
        cursor: pointer;
        color: #333;
    }
    @media only screen and (max-width: 900px) {
        .container {
            flex-direction: column;
        }
        .left, .right {
            width: 100%;
            flex: 1;
        }
    }
</style>
<body>
    <div class="container">

        <div class="left">
            <h2>Products</h2>
            <div id="productList"></div>
        </div>

        <div class="right">
            <h2>Add New Product</h2>
            <form enctype="multipart/form-data" id="addProductForm" method="post">
                <div class="form-group">
                    <label>Main Image</label>
                    <input type="file" id="productImage" name="image" accept="image/*" required>
                </div>
                <div class="form-group">
                    <label>Gallery Images</label>
                    <input type="file" id="galleryImages" name="gallery[]" accept="image/*" multiple>
                </div>

                <input type="text" id="productTitle" name="name" placeholder="Name" required>
                <textarea id="productDescription" name="description" placeholder="Description"></textarea>
                <input type="number" id="productPrice" name="price" placeholder="Price" required>

                <input type="number" id="sizeXS" name="XS" placeholder="XS">
                <input type="number" id="sizeS" name="S" placeholder="S">
                <input type="number" id="sizeM" name="M" placeholder="M">
                <input type="number" id="sizeL" name="L" placeholder="L">
                <input type="number" id="sizeXL" name="XL" placeholder="XL">

                <input type="checkbox" id="onOffer" name="on_offer"> On Offer?
                <input type="number" id="offerPrice" name="offer_price" placeholder="Offer Price" disabled>

                <select id="categoryId" name="category_id">
                    <option value="1">Clothing</option>
                    <option value="2">Shoes</option>
                </select>

                <select id="gender" name="gender">
                    <option value="men">Male</option>
                    <option value="women">Female</option>
                </select>

                <button id="addProductBtn" type="submit">Add Product</button>
            </form>
        </div>
    </div>

    <div class="popup-overlay" id="popupEdit">
        <div class="popup-content">
            <span class="popup-close" id="closePopup">&times;</span>
            <h2>Edit Product</h2>

            <div class="form-group">
                <label>Title</label>
                <input type="text" id="editTitle">
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" id="editPrice">
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea id="editDescription" rows="4"></textarea>
            </div>
            <div class="form-group">
                <label>Size XS</label>
                <input type="number" id="editXS">
            </div>
            <div class="form-group">
                <label>Size S</label>
                <input type="number" id="editS">
            </div>
            <div class="form-group">
                <label>Size M</label>
                <input type="number" id="editM">
            </div>
            <div class="form-group">
                <label>Size L</label>
                <input type="number" id="editL">
            </div>
            <div class="form-group">
                <label>Size XL</label>
                <input type="number" id="editXL">
            </div>
            <div class="form-group">
                <label>Gender</label>
                <select id="editGender">
                    <option value="men">Male</option>
                    <option value="women">Female</option>
                </select>
            </div>
            <div class="form-group">
                <input type="checkbox" id="editOffer"> On Offer?
            </div>
            <div class="form-group">
                <label>Offer Price</label>
                <input type="number" id="editOfferPrice" disabled>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select id="editCategory">
                    <option value="1">Clothing</option>
                    <option value="2">Shoes</option>
                </select>
            </div>
            <button id="saveEditBtn" class="buttonSecondary">Save Changes</button>
        </div>
    </div>

<script>
document.getElementById("onOffer").addEventListener("change", function() {
    document.getElementById("offerPrice").disabled = !this.checked;
});

document.getElementById("addProductForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const form = this;

    const sizeXS = parseInt(document.getElementById("sizeXS").value) || 0;
    const sizeS = parseInt(document.getElementById("sizeS").value) || 0;
    const sizeM = parseInt(document.getElementById("sizeM").value) || 0;
    const sizeL = parseInt(document.getElementById("sizeL").value) || 0;
    const sizeXL = parseInt(document.getElementById("sizeXL").value) || 0;
    const stock = sizeXS + sizeS + sizeM + sizeL + sizeXL;

    const onOffer = document.getElementById("onOffer").checked ? 1 : 0;
    const offerPrice = onOffer ? parseFloat(document.getElementById("offerPrice").value) || 0 : 0;

    const formData = new FormData(form);
    formData.append("stock", stock);
    formData.append("is_popular", 0);
    formData.set("on_offer", onOffer);
    formData.set("offer_price", offerPrice);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/ajax/post-admin-product.php", true);
    xhr.onload = function () {
        console.log(xhr.responseText);
        if (xhr.status === 200) {
            alert("Product added successfully!");
            form.reset();
            loadProducts();
        } else {
            alert("Error adding product.");
        }
    };
    xhr.send(formData);
});
</script>

<script>
function loadProducts() {
    $.ajax({
        url: "../php/ajax/get-admin-product.php",
        method: "GET",
        dataType: "json",
        success: function(products) {
            const container = $("#productList");
            container.empty();

            products.forEach(product => {
                const item = $(`
                    <div class="product-item" data-id="${product.id}">
                        <strong>${product.name}</strong><br>
                        Price: $${product.price} | Category: ${product.category_id}<br>
                        Stock: ${product.stock}
                    </div>
                `);
                item.on("click", () => openEditPopup(product));
                container.append(item);
            });
        },
        error: function() {
            console.error("Failed to load products.");
        }
    });
}

function openEditPopup(product) {
    $("#popupEdit").show();

    $("#editTitle").val(product.name);
    $("#editPrice").val(product.price);
    $("#editDescription").val(product.description);
    
    $("#editXS").val(product.XS || 0);
    $("#editS").val(product.S || 0);
    $("#editM").val(product.M || 0);
    $("#editL").val(product.L || 0);
    $("#editXL").val(product.XL || 0);

    $("#editCategory").val(product.category_id);
    $("#editGender").val(product.gender);
    $("#editOffer").prop("checked", product.on_offer == 1);
    $("#editOfferPrice").val(product.offer_price || 0).prop("disabled", product.on_offer != 1);

    $("#saveEditBtn").data("id", product.id);
}


$("#editOffer").on("change", function () {
    $("#editOfferPrice").prop("disabled", !this.checked);
});

$("#closePopup").on("click", function () {
    $("#popupEdit").fadeOut();
});

$(document).on("click", ".product-item", function () {
    const id = $(this).data("id");
    $.getJSON("../php/ajax/get-admin-product.php", { id }, function (product) {
        openEditPopup(product);
    });
});

loadProducts();
</script>
<script>
    $("#saveEditBtn").on("click", function () {
    const id = $(this).data("id");

    const data = {
        id: id,
        name: $("#editTitle").val(),
        price: parseFloat($("#editPrice").val()),
        description: $("#editDescription").val(),
        XS: parseInt($("#editXS").val()) || 0,
        S: parseInt($("#editS").val()) || 0,
        M: parseInt($("#editM").val()) || 0,
        L: parseInt($("#editL").val()) || 0,
        XL: parseInt($("#editXL").val()) || 0,
        gender: $("#editGender").val(),
        category_id: $("#editCategory").val(),
        on_offer: $("#editOffer").is(":checked") ? 1 : 0,
        offer_price: $("#editOffer").is(":checked") ? parseFloat($("#editOfferPrice").val()) || 0 : 0
    };

    $.ajax({
        url: "../php/ajax/update-admin-product.php",
        type: "POST",
        data: data,
        success: function (res) {
            alert("Product updated successfully!");
            $("#popupEdit").fadeOut();
            loadProducts();
        },
        error: function () {
            alert("Failed to update product.");
        }
    });
});
</script>

</body>
</html>