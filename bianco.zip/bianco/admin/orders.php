<?php 
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include '../php/conn.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT o.id, o.size, o.status, o.address, o.orderNumber, p.name, p.price, u.username
    FROM orders o
    JOIN products p ON o.productId = p.id
    JOIN users u ON o.userId = u.id
");
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard | Orders</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background: #f8f9fa;
      padding: 20px;
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
      font-size: 2.5rem;
      font-weight: 800;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      overflow: hidden;
      border-radius: 10px;
    }

    thead {
      background: #343a40;
      color: white;
    }

    th, td {
      padding: 16px;
      text-align: left;
      border-bottom: 1px solid #dee2e6;
      vertical-align: middle;
      max-width: 200px;
      word-break: break-all;
    }
    .price {
      font-weight: bold;
      color: #28a745;
    }
    button{
        background-color: hsl(0, 0%, 10%);
        outline: none;
        border: none;
        color: white;
        border-radius: 5px;
        padding: 10px;
        font-weight: 600;
        cursor: pointer;
    }
    @media (max-width: 768px) {
      table, thead, tbody, th, td, tr {
        font-size: 0.9rem;
      }

      td, th {
        padding: 10px;
      }
    }

    @media (max-width: 500px) {
      table {
        font-size: 0.8rem;
      }

      select {
        font-size: 0.8rem;
      }
    }
  </style>
</head>
<body>

<h1>Orders</h1>

<table>
  <thead>
    <tr>
      <th>User</th>
      <th>Product</th>
      <th>Price</th>
      <th>Address</th>
      <th>ON</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
  <?php 
    while ($row = $result->fetch_assoc()) {
      $status = $row['status'];
      $buttonColor = match ($status) {
        'Sent' => 'background-color: green; color: white;',
        'Canceled' => 'background-color: red; color: white;',
        'Kargo' => 'background-color: orange; color: white;',
        'Pending' => 'background-color: gray; color: white;',
        default => 'background-color: black; color: white;',
    };
    
  
      echo '<tr>';
      echo '<td>' . htmlspecialchars($row['username']) . '</td>';
      echo '<td>' . htmlspecialchars($row['name']) . '</td>';
      echo '<td class="price">$' . htmlspecialchars($row['price']) . '</td>';
      echo '<td>' . htmlspecialchars($row['address']) . '</td>';
      echo '<td>' . htmlspecialchars($row['orderNumber']) . '</td>';
      echo '<td>';
      echo '<button class="status-toggle-btn" data-order-id="' . $row['id'] . '" data-status="' . $status . '" style="' . $buttonColor . ' padding: 4px 10px; border: none; border-radius: 5px; cursor: pointer;">' . $status . '</button>';
      echo '</td>';
      echo '</tr>';
  }
  ?>
  </tbody>
</table>

</body>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.status-toggle-btn').forEach(button => {
      button.addEventListener('click', () => {
        const orderId = button.dataset.orderId;
        const currentStatus = button.dataset.status;

        const statuses = ['Pending', 'Sent', 'Kargo', 'Cancelled'];
        const currentIndex = statuses.indexOf(currentStatus);
        const newStatus = statuses[(currentIndex + 1) % statuses.length];

        fetch('../php/ajax/post-admin-orders.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `order_id=${orderId}&status=${newStatus}`
        })
        .then(res => res.text())
        .then(response => {
          console.log(response);
          location.reload();
        })
        .catch(err => console.error('Status toggle error:', err));
      });
    });
  });
</script>
</html>
