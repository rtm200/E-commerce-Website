<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | CheckOut</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/checkout.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
</head>
<body>
  <?php include_once "components/header.php" ?>

    <div class="gelAlNoktasi-container" id="gelAlNoktasi-container">
      <h4>Select Your Preferred Shop</h4>
      <p style="margin-bottom: 10px">Your order will go to the shop you select</p>
      <div class="gelAlNoktasi-map" id="map"></div>
    </div>
    <div class="gelAlNoktasi-blur" id="gelAlNoktasi-blur"></div>

    <div class="confirm-blur" id="confirm-blur" onclick="location.reload()"></div>
    <div class="confirm-container" id="confirm-container"> 
      <button class="confirm-dismiss" type="button" onclick="location.reload()">×</button> 
      <div class="confirm-header"> 
        <div class="confirm-image">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M20 7L9.00004 18L3.99994 13" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
          </div> 
          <div class="confirm-content">
            <span class="confirm-title">Order validated</span> 
            <p class="confirm-message">Thank you for your purchase. you package will be delivered within 7 days of your purchase</p> 
            </div> 
            <div class="confirm-actions">
              <a href="profile.php"  class="confirm-history">My Orders</a> 
              <a href="index.php" class="confirm-track">Continue</a> 
            </div> 
        </div> 
    </div>

 
    <div class="error-blur" id="error-blur" onclick="location.reload()"></div>
    <div class="error-container" id="error-container"> 
      <div class="error-header"> 
        <div class="error-div_image_v">
          <div class="error-image" onclick="location.reload()">
            <svg y="0" xmlns="http://www.w3.org/2000/svg" x="0" width="100" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" height="100" class="w-12 h-12 fill-current">
              <path fill-rule="evenodd" d="M50,87.4A37.4,37.4,0,1,0,12.6,50,37.3,37.3,0,0,0,50,87.4ZM44,37.3A4.7,4.7,0,0,0,37.3,44l6.1,6-6.1,6A4.7,4.7,0,0,0,44,62.7l6-6.1,6,6.1A4.7,4.7,0,0,0,62.7,56l-6.1-6,6.1-6A4.7,4.7,0,0,0,56,37.3l-6,6.1Z">
              </path>
            </svg>
          </div> 
        </div> 
        <div class="error-content">
          <span class="error-title">Order Failed!</span> 
          <p class="error-message">Your order has been failed please try again</p> 
        </div> 
      </div> 
    </div>
    


    <main>
        <div class="checkout-container">
           
            <div class="checkout-left">
              <div class="checkout-left-top">
                <h2>Your Order</h2>
                <div class="product-cards">

                  <!-- <div class="product-card">
                      <img src="img/kadin1.jpg">
                      <div class="product-details">
                        <h4>Elegant Dress</h4>
                        <p>Quantity: 2</p>
                        <p>Price: $90</p>
                      </div>
                    </div> -->
                
                </div>
            
                <div class="order-summary">
                  <h3>Order Summary</h3>
                  <p>Subtotal: <span id="checkout_subtotal">$0.00</span></p>
                  <p>Shipping: <span id="checkout_shipping">$0.00</span></p>
                  <p><strong>Total: <span id="checkout_total">$0.00</span></strong></p>
                  <p><i>Coupon: <span id="checkout_cupon">$0.00</span></i></p>
                </div>
              </div>
              <div class="offer">
                <input type="text" id="cuponInput" placeholder="Enter your Cupon">
                <span class="offerResult"></span>
              </div>
            </div>
          
            <div class="checkout-right">
              <h2>Payment & Address</h2>
          
              <div class="payment-form">
                
                <div class="form-section">
                  <div style=" display: flex; align-items: start; justify-content: space-between;">
                    <h3>Shipping Address</h3>
                    <span id="gelAlNoktasi-trigger" style="background: black; width: 30px; height: 30px; border-radius: 5px; display: flex; align-items: center; justify-content: center; cursor: pointer">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="white" d="M12 18H6v-4h6m9 0v-2l-1-5H4l-1 5v2h1v6h10v-6h4v6h2v-6m0-10H4v2h16z"/></svg>
                    </span>
                  </div>
                  <input type="text" placeholder="Address" id="address" required>
                </div>
          
                <div class="form-section">
                  <h3>Payment Details</h3>
                  <input type="text" id="cardName" placeholder="Cardholder Name" required>
                  <input type="text" id="cardNumber" placeholder="Card Number" required>
                  <div class="small-inputs">
                    <input type="text" id="mmyy" placeholder="MM/YY" required>
                    <input type="text" id="cvv" placeholder="CVV" required>
                  </div>
                </div>
          
                <button type="button" class="buttonSecondary" onclick="sendData()">Confirm & Pay</button>
              </div>
            </div>
          </div>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
<script>
  function loadCheckout(cuponDiscount = 0) {
    fetch('php/ajax/get-cart.php')
      .then(res => res.json())
      .then(data => {
        const subtotalEl = document.getElementById('checkout_subtotal');
        const shippingEl = document.getElementById('checkout_shipping');
        const totalEl = document.getElementById('checkout_total');
        const cuponEl = document.getElementById('checkout_cupon');
        const container = document.querySelector('.product-cards');
        container.innerHTML = '';

        if (data.length === 0) {
          container.innerHTML = '<p>Your cart is empty</p>';
          if (subtotalEl) subtotalEl.textContent = '$0.00';
          if (totalEl) totalEl.textContent = '$0.00';
          if (shippingEl) shippingEl.textContent = '$0.00';
          if (cuponEl) cuponEl.textContent = '-$0.00';
          return;
        }

        
        const groupedItems = {};
        data.forEach(item => {
          const key = `${item.prId}_${item.size}`;
          if (!groupedItems[key]) {
            groupedItems[key] = {
              ...item,
              quantity: 1
            };
          } else {
            groupedItems[key].quantity += 1;
          }
        });

        let subtotal = 0;

        Object.values(groupedItems).forEach(item => {
          const quantity = item.quantity;
          const itemTotal = parseFloat(item.price) * quantity;
          subtotal += itemTotal;

          container.innerHTML += `
            <div class="product-card">
              <img src="${item.image}">
              <div class="product-details">
                <h4>${item.name}</h4>
                <div style="display:flex; align-items:center; justify-content: space-between;">
                  <div>
                    <p>Size: ${item.size}</p>
                    <p>
                      ${item.original_price 
                        ? `<span style="text-decoration: line-through; color: gray;">$${item.original_price}</span> 
                          <span style="color: white; font-weight: normal;">$${item.price}</span>`
                        : `$${item.price}`
                      }
                    </p>
                    <p>Quantity: ${quantity}</p>
                    <p>Total: $${itemTotal.toFixed(2)}</p>
                  </div>
                  <span 
                    class="order-delete-btn"
                    data-order-id="${item.id}"
                    style="margin-top:10px; height: 28px; width: 28px; display: flex; align-items:center; justify-content: center; font-size: 0.875rem; font-weight: 500; color: hsl(0, 0%, 10%); background: white; border-radius: 6px; cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path fill="currentColor" d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"/><path fill="currentColor" d="M9 10h2v8H9zm4 0h2v8h-2z"/></svg>
                  </span>
                </div>
              </div>
            </div>`;
        });

        if (subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`;

        let shipping = 0;
        if (shippingEl) {
          shipping = subtotal >= 100 ? 0 : subtotal * 0.05;
          shippingEl.textContent = `$${shipping.toFixed(2)}`;
        }

        let total = subtotal + shipping - cuponDiscount;
        if (totalEl) {
          total = total < 0 ? 0 : total;
          totalEl.textContent = `$${total.toFixed(2)}`;
        }

        if (cuponEl) {
          cuponEl.textContent = `-$${cuponDiscount.toFixed(2)}`;
        }
      })
      .catch(err => console.error('Cart load error:', err));
  }
  loadCheckout();
</script>
  <script>
    document.querySelector('.product-cards').addEventListener('click', (e) => {
      const btn = e.target.closest('.order-delete-btn');
      if (!btn) return;

      const orderId = btn.getAttribute('data-order-id');

      fetch('php/ajax/delete-cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `cart_id=${orderId}`
      })
      .then(res => res.text())
      .then(response => {
        console.log('Deleted:', response);
        window.location.reload();
      })
      .catch(err => console.error('Delete error:', err));
    });
  </script>
<script>
  const cuponInput = document.getElementById('cuponInput');
  const offerResult = document.querySelector('.offerResult');
  const checkout_cupon = document.getElementById('checkout_cupon');

  cuponInput.addEventListener('input', function () {
    const cupon = this.value;

    if (cupon.length >= 3) {
      fetch('php/ajax/get-cupon.php?cupon=' + encodeURIComponent(cupon))
        .then(response => response.json())
        .then(data => {
          const discount = parseFloat(data.price) || 0;
          offerResult.textContent = data.message;
          loadCheckout(discount);
        })
        .catch(() => {
          offerResult.textContent = 'Something went wrong';
          loadCheckout(0);
        });
    } else {
      offerResult.textContent = 'not a valid cupon';
      loadCheckout(0);
    }
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
      const gelAlNoktasi_blur = document.getElementById('gelAlNoktasi-blur');
      const gelAlNoktasi_container = document.getElementById('gelAlNoktasi-container');
      const gelAlNoktasi_trigger = document.getElementById('gelAlNoktasi-trigger');

      gelAlNoktasi_trigger.addEventListener('click', function () {
        gelAlNoktasi_container.style.display = 'flex';
        gelAlNoktasi_blur.style.display = 'flex';
            
      });

      gelAlNoktasi_blur.addEventListener('click', function () {
        gelAlNoktasi_container.style.display = 'none';
        gelAlNoktasi_blur.style.display = 'none';
      });
    });
</script>


<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const gelAlNoktasi_blur = document.getElementById('gelAlNoktasi-blur');
    const gelAlNoktasi_container = document.getElementById('gelAlNoktasi-container');
    const gelAlNoktasi_trigger = document.getElementById('gelAlNoktasi-trigger');
    const addressDiv = document.getElementById('address');
    let mapInitialized = false;
    let map;


    const locations = [
      {
        coords: [41.008214, 28.954973],
        name: "Laleli Store",
        address: "Mesih Paşa, Mesihpaşa Cd., 34130 Fatih/İstanbul"
      },
      {
        coords: [41.05562424798336, 28.989154933625063],
        name: "Nişantaşı Store",
        address: "Teşvikiye, Akkavak Sk. No:12, 34365 Şişli/İstanbul"
      },
      {
        coords: [41.10585852145377, 29.02308118172113],
        name: "Maslak Store",
        address: "Maslak, 1453 Cd 27-45, 34398 Sarıyer/İstanbul"
      }
    ];

    gelAlNoktasi_trigger.addEventListener('click', function () {
      gelAlNoktasi_container.style.display = 'flex';
      gelAlNoktasi_blur.style.display = 'flex';

      if (!mapInitialized) {
        map = L.map('map').setView([41.05562424798336, 28.989154933625063], 10);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© BIANCO'
        }).addTo(map);

        locations.forEach(location => {
          const marker = L.marker(location.coords).addTo(map);
          marker.bindPopup(`<strong>${location.name}</strong>`);
       
          marker.on('mouseover', function() {
            this.openPopup();
          });
          marker.on('mouseout', function() {
            this.closePopup();
          });
          marker.on('click', function() {
            addressDiv.value = location.address;
            gelAlNoktasi_container.style.display = 'none';
            gelAlNoktasi_blur.style.display = 'none';
          });
        });

        mapInitialized = true;
      }
    });

    gelAlNoktasi_blur.addEventListener('click', function () {
      gelAlNoktasi_container.style.display = 'none';
      gelAlNoktasi_blur.style.display = 'none'; 
    });
  });
</script>
<script>
  function sendData() {
    const cardName = document.getElementById('cardName').value.trim();
    const cardNumber = document.getElementById('cardNumber').value.trim();
    const cvv = document.getElementById('cvv').value.trim();
    const mmyy = document.getElementById('mmyy').value.trim();
    const address = document.getElementById('address').value.trim();
    const cuponInput = document.getElementById('cuponInput').value.trim();

   
    if (!cardName || !cardNumber || !cvv || !mmyy || !address) {
      alert('Please fill in all required fields.');
      return;
    }

    const formData = new FormData();
    formData.append('cardName', cardName);
    formData.append('cardNumber', cardNumber);
    formData.append('cvv', cvv);
    formData.append('mmyy', mmyy);
    formData.append('address', address);
    formData.append('cuponInput', cuponInput);

    fetch('php/ajax/post-payment.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.text())
    .then(text => {
      console.log('Raw response:', text);
      try {
        const data = JSON.parse(text);
        console.log('Parsed JSON:', data);

        if (data.success) {
          document.getElementById('confirm-blur').style.display = 'flex';
          document.getElementById('confirm-container').style.display = 'flex';
        } else {
          document.getElementById('error-blur').style.display = 'flex';
          document.getElementById('error-container').style.display = 'flex';
        }
      } catch(e) {
        console.error('Error parsing JSON:', e);
        alert('Server response is not valid JSON. Check console.');
      }
    })
    .catch(error => {
      console.error('Fetch error:', error);
    });
  }
</script>
</html>