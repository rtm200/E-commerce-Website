<?php 
session_start();
require_once "php/conn.php";

if (!empty($_GET['id']) && is_numeric($_GET['id'])) {
    $productId = intval($_GET['id']);


    $stmt = $conn->prepare("UPDATE products SET is_popular = is_popular + 1 WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $productResult = $stmt->get_result();
    $product = $productResult->fetch_assoc();
    if (!empty($product['on_offer']) && $product['on_offer'] == 1 && !empty($product['offer_price'])) {
        $product['original_price'] = $product['price'];
        $product['price'] = $product['offer_price'];
    }
    $stmt->close();

    if (!$product) {
        die("Product not found.");
    }

    $sizeStocks = [
        'XS' => $product['XS'],
        'S'  => $product['S'],
        'M'  => $product['M'],
        'L'  => $product['L'],
        'XL' => $product['XL']
    ];

    $availableSizes = [];
    foreach ($sizeStocks as $size => $stock) {
        if ((int)$stock > 0) {
            $availableSizes[] = $size;
        }
    }

    $stmt = $conn->prepare("SELECT image FROM product_gallery WHERE product_id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $imagesResult = $stmt->get_result();
    $productImages = [];
    while ($img = $imagesResult->fetch_assoc()) {
        $productImages[] = $img['image'];
    }
    $stmt->close();
} else {
    die("Invalid product ID.");
}

$productTitle = $product['name'];
$productPrice = $product['price'];
$productDescription = $product['description'];
$productMainImage = $product['image'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?= htmlspecialchars($productTitle) ?> | Bianco</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="css/product.css">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
  <?php include_once "components/header.php" ?>

  <article class="product-container" role="main" aria-label="<?= htmlspecialchars($productTitle) ?> product details">
    <div class="product-gallery">
      <div class="main-image-wrapper">
        <img src="<?= htmlspecialchars($productMainImage) ?>" 
            alt="<?= htmlspecialchars($productTitle) ?>" 
            class="product-image main-product-image" 
            loading="lazy" 
            id="mainProductImg" />
        
        <div class="zoom-preview" id="zoomPreview"></div>
      </div>

      <?php if (!empty($productImages)): ?>
        <div class="gallery-thumbnails">
          <img src="<?= htmlspecialchars($productMainImage) ?>" alt="Thumbnail of <?= htmlspecialchars($productTitle) ?>" class="thumbnail" loading="lazy">
          <?php foreach ($productImages as $img): ?>
            <img src="<?= htmlspecialchars($img) ?>" alt="Thumbnail of <?= htmlspecialchars($productTitle) ?>" class="thumbnail" loading="lazy" />
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="product-details">
      <h1 class="product-title"><?= htmlspecialchars($productTitle) ?></h1>
      <p class="product-price">
        <?php if (!empty($product['original_price'])): ?>
          <span style="text-decoration: line-through; color: gray;">
            $<?= number_format($product['original_price'], 2) ?>
          </span>
          <span style="color: black;">
            $<?= number_format($product['price'], 2) ?>
          </span>
        <?php else: ?>
          $<?= number_format($product['price'], 2) ?>
        <?php endif; ?>
      </p>
      <p class="product-description"><?= htmlspecialchars($productDescription) ?></p>

      <label class="size-label" id="size-label" for="size-options">Size</label>
      <div class="sizes" role="radiogroup" aria-labelledby="size-label" id="size-options">
        <?php foreach($availableSizes as $index => $size): ?>
          <button
            class="size-option"
            type="button"
            role="radio"
            aria-checked="false"
            tabindex="<?= $index === 0 ? '0' : '-1' ?>"
            data-size="<?= htmlspecialchars($size) ?>"
          >
            <?= htmlspecialchars($size) ?>
          </button>
        <?php endforeach; ?>
      </div>

      <button id="addToCart" class="buttonSecondary" style="margin-top: 2rem;" type="button" aria-label="Add <?= htmlspecialchars($productTitle) ?> to cart" disabled>Add to Cart</button>
    </div>
  </article>

  <?php include_once "components/footer.php" ?>
</body>
<script>
  $(document).ready(function () {
    $('.thumbnail').on('click', function () {
      const newSrc = $(this).attr('src');
      $('.main-product-image').attr('src', newSrc);
    });
  });
</script>
<script>
  const mainImg = document.getElementById("mainProductImg");
  const zoomPreview = document.getElementById("zoomPreview");

  function isZoomEnabled() {
    return window.innerWidth >= 600;
  }

  mainImg.addEventListener("mouseenter", () => {
    if (isZoomEnabled()) {
      zoomPreview.style.display = "block";
      zoomPreview.style.backgroundImage = `url('${mainImg.src}')`;
    }
  });

  mainImg.addEventListener("mouseleave", () => {
    zoomPreview.style.display = "none";
  });

  mainImg.addEventListener("mousemove", function (e) {
    if (!isZoomEnabled()) return;

    const rect = this.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const percentX = (x / rect.width) * 100;
    const percentY = (y / rect.height) * 100;

    zoomPreview.style.left = "88%";
    zoomPreview.style.top = "0%";
    zoomPreview.style.backgroundPosition = `${percentX}% ${percentY}%`;
  });
</script>
<script>
  let selectedSize = null;
  const sizeButtons = document.querySelectorAll('.size-option');
  const addToCartBtn = document.getElementById('addToCart');

  sizeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      sizeButtons.forEach(b => {
        b.setAttribute('aria-checked', 'false');
        b.classList.remove('selected');
      });

      btn.setAttribute('aria-checked', 'true');
      btn.classList.add('selected');
      selectedSize = btn.dataset.size;
      addToCartBtn.disabled = false;
    });
  });

  addToCartBtn.addEventListener('click', () => {
    if (!selectedSize) return;

    const productId = <?= json_encode($productId) ?>;
    
    fetch('php/ajax/post-cart.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `product_id=${encodeURIComponent(productId)}&size=${encodeURIComponent(selectedSize)}`
    })
    .then(res => res.text())
    .then(response => {
      if (response === 'success') {
        console.log('Added to cart!');
        location.reload();
      } else {
        console.log('Error: ' + response);
      }
    })
    .catch(err => {
      console.error(err);
      alert('Something went wrong.');
    });
  });
</script>
</html>