<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | privacy</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<style> 
    h4{
        margin : 0 auto;
        width : 100%;
        display: flex;
        justify-content: center;
        margin:50px 0;
    }
    p{
        display: flex;
        justify-content: center;
        
    }
    main{
        padding: 0 200px 200px 200px;
    }
    @media only screen and (max-width: 600px) {
        h4{
            margin: 20px 0;
        }
        main{
            padding: 0 20px 20px 20px;
        }
    }
</style>
<body>
    <?php include_once "components/header.php" ?>
    <main> 
        <h4> PRİVACY AND COOKİES POLİCY </h4> 
        <p>1. WHO WE ARE. We are ITX TURKEY PERAKENDE İTHALAT İHRACAT VE TİCARET
        LİMİTED ŞİRKETİ and Industria de Diseño Textil, S.A. (Inditex, S.A.), S.A., and we process
        your personal data as joint controllers. This means that we are jointly responsible for how we
        process and protect your data. See more.<br>
        2. WHAT WE USE YOUR DATA FOR. We will use your data (collected online or
        in person), among other purposes, to manage your registration as a user, to manage your
        purchases of products or services, to respond to your queries, and, if you wish, to send you
        our customised communications. See more.<br>
        3. WHY WE USE YOUR DATA. We have legal standing to process your data for
        various reasons. The main reason is that we need to process your data to perform the
        contract that you accept with us when you register and when you make a purchase or enjoy
        any of our services or functionalities. We also use your data for other reasons, for example, to
        respond to your queries or to send you newsletters that you have asked to receive from us.
        See more.<br>
        4. WHO WE SHARE YOUR DATA WITH. We share your data with service
        providers who provide us with assistance or support, these being companies in the Inditex
        Group or third party providers. See more.
        5. YOUR RIGHTS. You have the right to access, rectify or delete your personal data. In
        certain cases, you are also entitled to other rights, such as, for example, to object to us using
        your data, or to transferring your data, as explained in depth below. See more.
        We encourage you to read our full Privacy and Cookies Policy below to understand in depth the
        manner in which we will use your personal data and your rights over your data </p><br>
        1. BEFORE YOU START …
        <br>● In this Privacy and Cookies Policy, you will find all relevant information applicable to our use of our users'
        and customers' personal data, regardless of the channel or means (online or in person) that you use to
        interact with us.
        <br>● If you would like information about how we use cookies and similar devices that may be installed on the
        terminals of our customers and users, we recommend you consult the Cookies Policy.
        <br>● We are transparent about what we do with your personal data, to help you to understand the implications of
        the way in which we use your data, and the rights you are entitled to in relation to your data:
        o We permanently make available for you all the information included in this Privacy and Cookies
        Policy, that you can check when you consider appropriate, and in addition,
        o you will also find further information on how we use your data as you interact with us.
        <br>● These are some terms we regularly use in this Privacy and Cookies Policy:
        o When we speak about our Platform, we refer, in general, to any of the channels or means, digital or
        in person, you may have used to interact with us. The main ones are:
        ▪ Our Website.
        ▪ Our App, this is, including both the mobile application you installed on your device and others
        we may use in our Platform.
        ▪ In person, in any of our Brick-and-Mortar Stores.
        1. WHO IS THE CONTROLLER OF YOUR DATA?
        Your data controllers are:
        ▪ ITX TURKEY PERAKENDE İTHALAT İHRACAT VE TİCARET LİMİTED ŞİRKETİ, company currently
        operating in Turkey the sale of ZARA brand products ("ZARA TURKEY"):
        o Postal address: MM Plaza; Nispetiye Mahallesi, Aytar Caddesi, Başlık Sokak, No:3, Kat: 4, 34340,
        İstanbul.
        o E-mail of Data Protection Officer: dataprotection@zara.com
        ▪ INDUSTRIA DE DISEÑO TEXTIL, S.A. (INDITEX, S.A.), S.A. ("INDITEX"):
        o Postal address: Avda. de la Diputación, Edificio Inditex, 15143, Arteixo (A Coruña), Spain.
        o E-mail of Data Protection Officer: dataprotection@zara.com
        In other words, both ZARA TURKEY and INDITEX (jointly “We”, “Us” or “the Joint Controllers”), are Joint Controllers
        of the data. This means that we have regulated and are jointly responsible for processing and protecting your personal
        data.<br>
        2. WHY DO WE PROCESS YOUR PERSONAL DATA?
        Depending on the purpose for which we process your data from time to time, as explained below, we need to process
        one or other data, which will in general be, depending on each case, as follows:
        ▪ your identity data (for example, your name, surname, image, language and country from which you interact
        with us, contact data, etc.);
        ▪ economic and transactions information (for example, your payment or card data, information on your
        purchases, orders, returns, etc.);
        ▪ connection, geolocation and/or browsing data (for example, the location data, the device identification
        number or the advertising ID, etc.);
        ▪ commercial information (for example, if you have subscribed to our newsletter),
        ▪ information about your tastes and preferences.
        ▪ special categories of data may be necessary (e.g. health data in cases where it is necessary to manage
        certain incidents such as those related to cosmetic products).
        Remember that, when we ask you to fill in your personal data to give you access to any functionality or service of the
        Platform, we will mark certain fields as compulsory, since this is information that we need to be able to provide the
        service or give you access to the functionality in question. Please take into account that, if you decide not to make
        such data available to us, you may be unable to complete your user registration or may not be able to enjoy those
        services or functionalities.
        In specific cases, a third party may have provided us with information about you by using a feature or service on the
        Platform, for example by sending you a gift card or shipping an order to your address. In these cases, we only process
        your data where relevant to this feature or service, as stated in this Privacy and Cookies Policy.
        In other cases, we may collect information passively, as we may use tracking tools like browser cookies and other
        similar technology on our Platform and in communications we send you.
        Depending on how you interact with our Platform, i.e., depending on the services, products or functionalities that you
        wish to enjoy, we will process your personal data for the following purposes:
        PURPOSE + info<br>
        1. To manage your registration
        as user of the Platform
        If you decide to become a registered user of our Platform, we need to process
        your data to identify you as a user of the Platform and grant you access to its
        various functionalities, products and services available to you as a registered
        user. You may cancel your registered user account by contacting us through
        Customer Service.
        We hereby inform you that the data we gather regarding your activity, which have
        been collected through the different channels of the Platform and which include
        your purchases, shall remain linked to your account so that all the information
        can be accessed together.<br>
        2. For the development,
        performance and execution of
        the purchase or services
        contract that you executed with
        Us on the Platform
        This purpose includes processing your data, mainly:
        ▪ To contact you for updates or informative notices related to the
        contracted functionalities, products or services, including quality
        surveys and to be able to establish the degree of customer satisfaction
        with the provided service;
        ▪ To manage payment of the products that you purchase, regardless of
        the payment procedure used. For example:
        4
        PURPOSE + info
        ▪ If on purchasing any of our products through the Website or the App, you opt
        to activate the functionality of save your payment data and your shipment
        address for future purchases (where this feature available), we need to
        process the indicated data for activation and development of that
        functionality. Consent to the activation of this functionality enables your
        autocompleted payment data to appear in subsequent purchases so that you
        do not need to introduce them in each new process, and these data will be
        deemed valid and effective for subsequent purchases. You may change or
        cancel your payment data at any time through the section on payment
        information, either of your Website registered user account, or of the My
        Account section of the App.
        ▪ To activate the mechanisms necessary to prevent and detect
        unauthorised uses of the Platform (for example, during the purchase
        and returns process) as well as potential fraud being committed
        against you and/or against us. If we consider that the transaction may
        be fraudulent or we detect abnormal behaviour which indicates
        attempted fraudulent use of our features, products or services, this
        processing may result in consequences such as the blocking of the
        transaction or the deletion of your user account.
        ▪ To manage potential exchanges or returns after you have purchased
        and manage requests of availability information for articles,
        reservations of products through the Platform, depending on the
        availability of such options from time to time.
        ▪ For invoicing purposes and to make available to you the tickets and
        invoices of the purchases you have made through the Platform.
        ▪ To ensure that you are able to use other available functionalities or
        services, such as the purchase, receipt, management and use of the
        Gift Card or of the Gift Voucher, and to afford you access and use of
        the Wi-Fi that we make available to our customers at Brick-and-Mortar
        Stores.
        ▪ To be able to offer you specific personalized services (such as item
        finder, reserve a fitting room, etc.) available in some Brick-and-Mortar
        Stores, we may process your location and contact data.
        ▪ Finally, we may process your data for the fulfilment of any legal
        obligations that may be applicable.<br>
        3. To meet requests or
        applications that you make
        through the Customer Support
        channels
        We only process the personal data that are strictly necessary to manage or
        resolve your request or application.
        If you contact us via telephone, the call may be recorded for quality purposes
        and so that we can respond to your request.
        If it is available, and you choose to use WhatsApp as a channel to communicate
        with Customer Support, we will share your telephone number with WhatsApp
        Inc. (a company located in the U.S.A.) to confirm that you are a user of this
        service. We recommend you review your privacy settings and to read WhatsApp
        privacy policy to obtain more detailed information about the use that WhatsApp
        makes of the personal data of the users that use their services.
        If it is available and you choose to communicate with Customer Support through
        the chat service of a social network or another collaborator, some of your
        personal data such as your name or user name, will be imported from your social
        5
        PURPOSE + info
        network or collaborator account. Also, bear in mind that the data you submit on
        this service will be available to your social network or collaborator and subject to
        their privacy policies, therefore We recommend you to review your privacy
        settings and to read the social network or collaborator privacy policies to obtain
        more detailed information about the use they make of your personal data when
        using their services.<br>
        4. For marketing purposes. This purpose includes the processing of your data, mainly, for:
        ▪ Personalise the services we offer you and enable us to give you
        recommendations based on your interactions with us on the Platform
        and an analysis of your user profile (for example, based on your
        purchase and browsing history).
        ▪ If and when you subscribe to our Newsletter, we will process your
        personal data to manage your subscription, including to send
        customised information on our products or services through various
        means (such as e-mail or SMS). We may also make available to you this
        information through push notifications in case you have activated them
        in your device.
        ▪ Accordingly, please take into account that this data processing implies
        analysis of your user or customer profile to establish your
        preferences and therefore which products and services are most fit to
        your style when sending you information. For example, based on your
        purchases and browsing history (i.e., depending on the articles that you
        clicked), we will make you suggestions on products that we believe may
        interest you and, if you are a registered user, we will provide you with
        the "recover cart" functionality.
        ▪ Remember that you may unsubscribe from the Newsletter at any
        time without cost through the "Newsletter" section of the Platform, in
        addition to through the instructions that we provide you with in each
        notice. If you do not want to receive push notifications, you can
        deactivate this option in your device.
        ▪ Show you ads on the Internet which you may see when visiting
        websites and apps, for example, on social media. The ads you see may
        be random, but on other occasions they may be ads related to your
        preferences or purchase and browsing history.
        ▪ If you use social media, we may provide the companies with which we
        collaborate certain information so that they can show you our brand ads
        and, in general, offer you and users like you advertisements which take
        into account your profile on said social media sites. If you want
        information about the use of your data and how advertising works on
        social media, we recommend you review the privacy policies of the
        social media sites on which you have profiles.
        ▪ We also use your data to carry out measurement and segment
        analyses on the ads which we show users on some of our collaborators’
        platforms. To do this we collaborate with these third parties who offer
        us the necessary technology (for example, cookies, pixels, SDK) to use
        these services. Keep in mind that, although we do not provide
        identifying personal data to these collaborators, we do give them some
        form of identifier each time (for example, the advertising ID associated
        with the device, an identifier associated with a cookie, etc.) If you would
        like more information in this respect, please review our Cookies Policy.
        Likewise, you can reset your advertising ID or disable personalised ads<br>
        6.
        PURPOSE + info
        on your device, adjusting your preferences in settings section of your
        device.
        ▪ Data enrichment: When we gather your personal data from a variety of
        sources, we may consolidate them under certain circumstances for the
        purpose of improving our understanding of your needs and preferences
        related to our products and services (including for the purposes of
        analyses, generating user profiles, marketing studies, quality surveys
        and improving our interactions with our customers). This refers, for
        example, to the way we may combine your information if you have a
        registered account and, using the same email linked to your account,
        you make a purchase as a guest, or to information which is automatically
        compiled (such as IP and MAC addresses or metadata) which we may
        link with the information you have provided us directly through your
        activity on the Platform or in any of our stores (for example, information
        related to your purchases, whether in brick and mortar stores or online,
        your preferences, etc.).
        ▪ To perform promotional actions (for example, for the organization of
        competitions or to send the list of items stored to the e-mail you
        designate). On participating in any promotional action, you authorise us
        to process the personal data that you have shared with us depending on
        the promotional action and disclose them through different media such
        as social networks or the Platform itself. In each promotional action in
        which you participate you will have available the terms and conditions
        where we will be providing more detailed information about the
        processing of your personal data.
        ▪ To disseminate in the Platform or through our channels in the social
        networks photographs or pictures that you shared publicly, provided that
        you expressly give us your consent for the purpose.<br>
        5. Analysis of usability and
        quality to improve our services
        If you access our Platform, we inform you that we will treat your data for analytic
        and statistic purposes, i.e., to understand the manner in which users interact
        with our Platform and with the actions we implement on other websites and apps,
        so we can improve our services.
        In addition, we occasionally perform quality surveys and actions to know the
        degree of satisfaction of our customers and users and detect those areas in
        which we may improve.
        </p>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>