<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include_once "php/conn.php";

    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $email && $password) {

        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            echo "Username or email already taken.";
            $check->close();
            exit();
        }
        $check->close();

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashedPassword, $email);

        if ($stmt->execute()) {
            header("Location: login.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bianco | register</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <?php include_once "components/header.php" ?>
    <main>
        <div class="left">
            <div class="form-container">
            <div class="logo-container">Register</div>
            <form class="form" method="POST">
                <div class="form-group">
                    <label for="email">Username</label>
                    <input type="text" name="username" placeholder="Enter your username" required="">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" placeholder="Enter your email" required="">
                </div>
                <div class="form-group">
                    <label for="email">Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required="">
                </div>
                <button class="form-submit-btn" type="submit">Register</button>
            </form>
            <p class="signup-link">
                Already have an account?
                <a href="login.php" class="signup-link link">Login up now</a>
            </p>
            </div>
        </div>

        <section class="right" id="map">
            <div class="right-container">
            <div style="display: flex; align-items: center; gap: 5px; color: white;">
                <span class="bianco" style="font-size: 4rem;">BIANCO</span>
                <span class="essentia" style="font-size: 2rem;">Essentia</span>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit...</p>
            </div>
        </section>
    </main>
    <?php include_once "components/footer.php" ?>
</body>
</html>